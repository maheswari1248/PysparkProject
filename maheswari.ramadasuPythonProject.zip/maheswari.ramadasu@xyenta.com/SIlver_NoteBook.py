# Databricks notebook source


# COMMAND ----------

import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, lower, to_timestamp
from datetime import datetime

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True,inferSchema=True)
len_emp = len(employee.columns)

# Assuming 'employee' is your DataFrame

# Get the column names
columns = employee.columns

# Convert the column names to lowercase and remove spaces
for column in columns:
    new_column_name = column.lower().replace(" ", "")
    employee = employee.withColumnRenamed(column, new_column_name)
    employee = employee.withColumnRenamed("attendencedate", "attendancedate")

# Print the column names after conversion
print(employee.columns)

XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True,inferSchema=True)
len_holiday = len(XyentaHolidays.columns)

Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True,inferSchema=True)
len_leaves = len(Xyenta_Leaves.columns) - 3

Total = len_emp + len_holiday + len_leaves

# Reading the Metadata Columns
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()

# Function to convert datatypes
def convert_datatypes(employee, Metadata):
    if Total == column_count:
        for row in Metadata.collect():
            source_columns = row['Columns']
            source_datatype = row['SourceDataType']
            target_datatype = row['TargetDataType']
            
            if source_columns in employee.columns:
                # Iterate over each column and count the null values
                null_counts = {col_name: employee.filter(col(col_name).isNull()).count() for col_name in employee.columns}
                
                # Print the null counts for each column
                
                
                # Check for duplicates
                count_duplicates = employee.groupBy(employee.columns).count().filter("count > 1")
        for col_name, count in null_counts.items():
                   print(f"Null count in {col_name}: {count}")        
        print("Duplicate rows count:") 
        count_duplicates.show() 
        employee.printSchema()   
        
        # Get today's date
        today_date = datetime.now()

        # Convert string to timestamp
        timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

        # Extract year, month, day, hour, minute, and second
        year = today_date.year
        month = today_date.month
        day = today_date.day
        hour = today_date.hour
        minute = today_date.minute
        second = today_date.second

        # Define the output path including the year, month, day, hour, minute, and second folders
        output_path = f"dbfs:/Landing/Silver/{year}/{month}/{day}/{hour}/{minute}/{second}/"
        if os.path.exists(output_path):
            print("Output path already exists, reading from existing path...")
            spark.read.parquet(output_path)
        else:
            print("Output path does not exist, creating the path...")
            # Write DataFrame to Parquet file
            employee.write.mode("overwrite").parquet(output_path)

    else:
        print("Total number of columns does not match the number of columns in Metadata.")

# Calling the function
convert_datatypes(employee, Metadata)


# COMMAND ----------

output_path = f"dbfs:/Landing/Silver/{year}/{month}/{day}/{hour}/{minute}/{second}/"
s=spark.read.parquet(output_path)
s.printSchema()

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

XyentaHolidays1 = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True)
print("Before Changing")
XyentaHolidays1.printSchema()
columns=XyentaHolidays.columns
for column in columns:
    new_column_name = column.lower().replace(" ", "")
    XyentaHolidays = XyentaHolidays.withColumnRenamed(column, new_column_name)
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
Metadata = Metadata.withColumn("Columns", 
                    when(col("Columns") == "holidayname", "holiday")
                    .when(col("Columns") == "holidaydate", "date")
                    .otherwise(col("Columns")))
for row in Metadata.collect():
    source_columns = row['Columns']
    
    if source_columns in XyentaHolidays.columns:
        XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
        #Iterate over each column and count the null values
        null_counts = {col_name: XyentaHolidays.filter(XyentaHolidays[col_name].isNull()).count() for col_name in XyentaHolidays.columns}
        for col_name, count in null_counts.items():
            print(f"Null count in {col_name}: {count}") 
        # Check for duplicates
        count_duplicates = XyentaHolidays.groupBy(XyentaHolidays.columns).count().filter("count > 1")

print("Duplicates count is")
count_duplicates.show() 
print("Data type is changed:")
XyentaHolidays.printSchema()


            

# COMMAND ----------



# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Read the CSV file
Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True,inferSchema=True)

# Rename columns to lowercase and remove spaces
Xyenta_Leaves = Xyenta_Leaves.toDF(*[col.lower().replace(" ", "") for col in Xyenta_Leaves.columns])

# Drop specified columns
# columns_to_drop = ['employeeno', 'slno', 'name']
# Xyenta_Leaves = Xyenta_Leaves.drop(*columns_to_drop)

# Drop null values
Xyenta_Leaves = Xyenta_Leaves.na.drop(subset=['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

# Drop duplicates
Xyenta_Leaves_dup = Xyenta_Leaves.dropDuplicates(['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

# Count duplicates
count_duplicates = Xyenta_Leaves_dup.groupBy('managerno', 'managername', 'leavetype','date','transactiontype','reason','days').count().filter("count > 1")
print("Duplicates count:")
count_duplicates.show()

# Count Nulls
null_counts = {col_name: Xyenta_Leaves.filter(Xyenta_Leaves[col_name].isNull()).count() for col_name in Xyenta_Leaves.columns}
for col_name, count in null_counts.items():
    print(f"Null count in {col_name}: {count}")

Xyenta_Leaves.printSchema()
display(Xyenta_Leaves)

# Save to Parquet file
# Xyenta_Leaves_dup.write.parquet("dbfs:/Processed/Xyenta_Leaves_Processed.parquet", mode="overwrite")


# COMMAND ----------

#####MAIN##########################################################


import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, lower, to_timestamp
from datetime import datetime

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True,inferSchema=True)
len_emp = len(employee.columns)

# Assuming 'employee' is your DataFrame

# Get the column names
columns = employee.columns

# Convert the column names to lowercase and remove spaces
for column in columns:
    new_column_name = column.lower().replace(" ", "")
    employee = employee.withColumnRenamed(column, new_column_name)
    employee = employee.withColumnRenamed("attendencedate", "attendancedate")

# Print the column names after conversion
print(employee.columns)

XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True,inferSchema=True)
len_holiday = len(XyentaHolidays.columns)
columns_XyentaHolidays=XyentaHolidays.columns
for column in columns_XyentaHolidays:
    new_column_name = column.lower().replace(" ", "")
    XyentaHolidays = XyentaHolidays.withColumnRenamed(column, new_column_name)

Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True,inferSchema=True)
Xyenta_Leaves = Xyenta_Leaves.toDF(*[col.lower().replace(" ", "") for col in Xyenta_Leaves.columns])
# columns_to_drop = ['employeeno', 'slno', 'name']
# Xyenta_Leaves = Xyenta_Leaves.drop(*columns_to_drop)
len_leaves = len(Xyenta_Leaves.columns)-3 

Total = len_emp + len_holiday + len_leaves


# Reading the Metadata Columns
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()

#Function to convert datatypes
if Total == column_count:
    def Employees(employee, Metadata):
        
            for row in Metadata.collect():
                source_columns = row['Columns']
                source_datatype = row['SourceDataType']
                target_datatype = row['TargetDataType']
                
                if source_columns in employee.columns:
                    # Iterate over each column and count the null values
                    null_counts = {col_name: employee.filter(col(col_name).isNull()).count() for col_name in employee.columns}
                    
                    # Print the null counts for each column
                    
                    
                    # Check for duplicates
                    count_duplicates = employee.groupBy(employee.columns).count().filter("count > 1")
            for col_name, count in null_counts.items():
                    print(f"Null count in {col_name}: {count}")        
            print("Duplicate rows count:") 
            count_duplicates.show() 
            employee.printSchema()   
            
            # Get today's date
            today_date = datetime.now()

            # Convert string to timestamp
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
            year = today_date.year
            month = today_date.month
            day = today_date.day
            hour = today_date.hour
            minute = today_date.minute
            second = today_date.second
            emp='employee'
            # Define the output path including the year, month, day, hour, minute, and second folders
            output_path = f"dbfs:/Landing/Silver/{emp}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
            if os.path.exists(output_path):
                print("Output path already exists, reading from existing path...")
                spark.read.parquet(output_path)
            else:
                print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
                employee.write.mode("overwrite").parquet(output_path)

        
    def XyentaHoliday(XyentaHolidays, Metadata):
        for row in Metadata.collect():
            source_columns = row['Columns']
        
            if source_columns in XyentaHolidays.columns:
                XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
                # Iterate over each column and count the null values
                null_counts = {col_name: XyentaHolidays.filter(XyentaHolidays[col_name].isNull()).count() for col_name in XyentaHolidays.columns}
                for col_name, count in null_counts.items():
                    print(f"Null count in {col_name}: {count}") 
                # Check for duplicates
                count_duplicates = XyentaHolidays.groupBy(XyentaHolidays.columns).count().filter("count > 1")
                print("Duplicates count is")
                count_duplicates.show() 
                print("Data type is changed:")
                XyentaHolidays.printSchema()
            today_date = datetime.now()

            # Convert string to timestamp
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
            year = today_date.year
            month = today_date.month
            day = today_date.day
            hour = today_date.hour
            minute = today_date.minute
            second = today_date.second
            Xyenta='XyentaHoliday'

            # Define the output path including the year, month, day, hour, minute, and second folders
        output_path = f"dbfs:/Landing/Silver/{Xyenta}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
        if os.path.exists(output_path):
            print("Output path already exists, reading from existing path...")
            s=spark.read.parquet(output_path)
            s.printSchema()
        else:
            print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
            XyentaHolidays.write.mode("overwrite").parquet(output_path)
    def XyentaLeaves(Xyenta_Leaves, Metadata):
        Xyenta_Leaves = Xyenta_Leaves.na.drop(subset=['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

    # Drop duplicates
        Xyenta_Leaves_dup = Xyenta_Leaves.dropDuplicates(['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

        # Count duplicates
        count_duplicates = Xyenta_Leaves_dup.groupBy('managerno', 'managername', 'leavetype','date','transactiontype','reason','days').count().filter("count > 1")
        print("Duplicates count:")
        count_duplicates.show()

        # Count Nulls
        null_counts = {col_name: Xyenta_Leaves.filter(Xyenta_Leaves[col_name].isNull()).count() for col_name in Xyenta_Leaves.columns}
        for col_name, count in null_counts.items():
            print(f"Null count in {col_name}: {count}")
        today_date = datetime.now()

            # Convert string to timestamp
        timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
        year = today_date.year
        month = today_date.month
        day = today_date.day
        hour = today_date.hour
        minute = today_date.minute
        second = today_date.second
        Xyenta='XyentaLeaves'

            # Define the output path including the year, month, day, hour, minute, and second folders
        output_path = f"dbfs:/Landing/Silver/{Xyenta}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
        if os.path.exists(output_path):
            print("Output path already exists, reading from existing path...")
            s=spark.read.parquet(output_path)
            s.printSchema()
        else:
            print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
            Xyenta_Leaves.write.mode("overwrite").parquet(output_path)


else:
    print("Total Count Doesnot Matches")
XyentaLeaves(Xyenta_Leaves, Metadata)

# COMMAND ----------


o='dbfs:/Landing/Silver/XyentaLeaves/2024/3/11/6/47/45/part-00000-tid-2770039166607128257-0f59413a-f75e-4e29-89b0-116b2546954d-672-1-c000.snappy.parquet'
s=spark.read.parquet(o)
s.printSchema()
# null_counts = {col_name: o.filter(Xyenta_Leaves[col_name].isNull()).count() for col_name in o.columns}
# for col_name, count in null_counts.items():
#      print(f"Null count in {col_name}: {count}")
display(s)

# COMMAND ----------

import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_timestamp
from datetime import datetime

def process_dataframe(df, metadata, folder_name):
    # Convert column names to lowercase
    df = df.toDF(*[col.lower() for col in df.columns])
    
    # Drop any rows with missing values
    df = df.na.drop()
    
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()

    # Get current timestamp
    today_date = datetime.now()
    timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))
    year = today_date.year
    month = today_date.month
    day = today_date.day
    hour = today_date.hour
    minute = today_date.minute
    second = today_date.second

    #Define the output path
    output_path = f"dbfs:/Landing/Silver/{folder_name}/{year}/{month}/{day}/{hour}/{minute}/{second}/"

    # Check if the output path exists
    if os.path.exists(output_path):
        print("Output path already exists, reading from existing path...")
        df = spark.read.parquet(output_path)
        df.printSchema()
    else:
        print("Output path does not exist, creating the path...")
        df.write.mode("overwrite").parquet(output_path)

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True, inferSchema=True)

# Assuming 'employee', 'XyentaHolidays', and 'Xyenta_Leaves' are your DataFrames

# Process each DataFrame
process_dataframe(employee, Metadata, "Employee")
process_dataframe(XyentaHolidays, Metadata, "XyentaHolidays")
process_dataframe(Xyenta_Leaves, Metadata, "XyentaLeaves")


# COMMAND ----------

import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_timestamp
from datetime import datetime

def process_dataframe(df, metadata, folder_name):
    # Convert column names to lowercase
    df = df.toDF(*[col.lower() for col in df.columns])
    
    # Drop any rows with missing values
    df = df.na.drop()
    
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()

    # Get current timestamp
    today_date = datetime.now()
    timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))
    year = today_date.year
    month = today_date.month
    day = today_date.day
    hour = today_date.hour
    minute = today_date.minute
    second = today_date.second

    # Define the output path
    output_path = f"dbfs:/Landing/Silver/{folder_name}/{year}/{month}/{day}/{hour}/{minute}/{second}/"

    # Check if the output path exists
    if os.path.exists(output_path):
        print("Output path already exists, reading from existing path...")
        df = spark.read.parquet(output_path)
        df.printSchema()
    else:
        print("Output path does not exist, creating the path...")
        df.write.mode("overwrite").parquet(output_path)
    
    # Return the processed DataFrame and column count
    return df, len(df.columns)

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True, inferSchema=True)

# Assuming 'employee', 'XyentaHolidays', and 'Xyenta_Leaves' are your DataFrames

# Process each DataFrame
employee_processed, employee_columns_count = process_dataframe(employee, Metadata, "Employee")
XyentaHolidays_processed, xyenta_holidays_columns_count = process_dataframe(XyentaHolidays, Metadata, "XyentaHolidays")
Xyenta_Leaves_processed, xyenta_leaves_columns_count = process_dataframe(Xyenta_Leaves, Metadata, "XyentaLeaves")

# Print column counts
print("Employee Columns Count:", employee_columns_count)
print("XyentaHolidays Columns Count:", xyenta_holidays_columns_count)
print("XyentaLeaves Columns Count:", xyenta_leaves_columns_count)


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------




# COMMAND ----------


#Function to convert datatypes
if Total == column_count:
    def Employees(employee, Metadata):
        
            for row in Metadata.collect():
                source_columns = row['Columns']
                source_datatype = row['SourceDataType']
                target_datatype = row['TargetDataType']
                
                if source_columns in employee.columns:
                    # Iterate over each column and count the null values
                    null_counts = {col_name: employee.filter(col(col_name).isNull()).count() for col_name in employee.columns}
                    
                    # Print the null counts for each column
                    
                    
                    # Check for duplicates
                    count_duplicates = employee.groupBy(employee.columns).count().filter("count > 1")
            for col_name, count in null_counts.items():
                    print(f"Null count in {col_name}: {count}")        
            print("Duplicate rows count:") 
            count_duplicates.show() 
            employee.printSchema()   
            
            # Get today's date
            today_date = datetime.now()

            # Convert string to timestamp
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
            year = today_date.year
            month = today_date.month
            day = today_date.day
            hour = today_date.hour
            minute = today_date.minute
            second = today_date.second
            emp='employee'
            # Define the output path including the year, month, day, hour, minute, and second folders
            output_path = f"dbfs:/Landing/Silver/{emp}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
            if os.path.exists(output_path):
                print("Output path already exists, reading from existing path...")
                spark.read.parquet(output_path)
            else:
                print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
                employee.write.mode("overwrite").parquet(output_path)

        
    def XyentaHoliday(XyentaHolidays, Metadata):
        for row in Metadata.collect():
            source_columns = row['Columns']
        
            if source_columns in XyentaHolidays.columns:
                XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
                # Iterate over each column and count the null values
                null_counts = {col_name: XyentaHolidays.filter(XyentaHolidays[col_name].isNull()).count() for col_name in XyentaHolidays.columns}
                for col_name, count in null_counts.items():
                    print(f"Null count in {col_name}: {count}") 
                # Check for duplicates
                count_duplicates = XyentaHolidays.groupBy(XyentaHolidays.columns).count().filter("count > 1")
                print("Duplicates count is")
                count_duplicates.show() 
                print("Data type is changed:")
                XyentaHolidays.printSchema()
            today_date = datetime.now()

            # Convert string to timestamp
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
            year = today_date.year
            month = today_date.month
            day = today_date.day
            hour = today_date.hour
            minute = today_date.minute
            second = today_date.second
            Xyenta='XyentaHoliday'

            # Define the output path including the year, month, day, hour, minute, and second folders
        output_path = f"dbfs:/Landing/Silver/{Xyenta}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
        if os.path.exists(output_path):
            print("Output path already exists, reading from existing path...")
            s=spark.read.parquet(output_path)
            s.printSchema()
        else:
            print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
            XyentaHolidays.write.mode("overwrite").parquet(output_path)
    def XyentaLeaves(Xyenta_Leaves, Metadata):
        Xyenta_Leaves = Xyenta_Leaves.na.drop(subset=['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

    # Drop duplicates
        Xyenta_Leaves_dup = Xyenta_Leaves.dropDuplicates(['managerno', 'managername', 'leavetype','date','transactiontype','reason','days'])

        # Count duplicates
        count_duplicates = Xyenta_Leaves_dup.groupBy('managerno', 'managername', 'leavetype','date','transactiontype','reason','days').count().filter("count > 1")
        print("Duplicates count:")
        count_duplicates.show()

        # Count Nulls
        null_counts = {col_name: Xyenta_Leaves.filter(Xyenta_Leaves[col_name].isNull()).count() for col_name in Xyenta_Leaves.columns}
        for col_name, count in null_counts.items():
            print(f"Null count in {col_name}: {count}")
        today_date = datetime.now()

            # Convert string to timestamp
        timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))

            # Extract year, month, day, hour, minute, and second
        year = today_date.year
        month = today_date.month
        day = today_date.day
        hour = today_date.hour
        minute = today_date.minute
        second = today_date.second
        Xyenta='XyentaLeaves'

            # Define the output path including the year, month, day, hour, minute, and second folders
        output_path = f"dbfs:/Landing/Silver/{Xyenta}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
        if os.path.exists(output_path):
            print("Output path already exists, reading from existing path...")
            s=spark.read.parquet(output_path)
            s.printSchema()
        else:
            print("Output path does not exist, creating the path...")
                # Write DataFrame to Parquet file
            Xyenta_Leaves.write.mode("overwrite").parquet(output_path)

# COMMAND ----------

employee = spark.read.csv("dbfs:/Landing/Bronze/EmployeeLoginDetails.csv", header=True,inferSchema=True)
len_emp = len(employee.columns)
print(len_emp)

Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()
print(column_count)

# COMMAND ----------

import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_timestamp
from datetime import datetime
employee = spark.read.csv("dbfs:/Landing/Bronze/EmployeeLoginDetails.csv", header=True,inferSchema=True)
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
def Employees(employee, Metadata):
    columns=employee.columns
    for column in columns:
        new_column_name = column.lower().replace(" ", "")
        employee = employee.withColumnRenamed(column, new_column_name)
        
       
    for row in Metadata.collect():
        source_columns = row['Columns']
        source_datatype = row['SourceDataType']
        target_datatype = row['TargetDataType']

        if source_columns in employee.columns:
            # Check if target data type matches the data type of employee columns
            target_data_types = employee.select(source_columns).dtypes
            for col_name, dtype in target_data_types:
                if dtype != target_datatype:
                    print(f"Error: Target data type of column {source_columns} ({target_datatype}) does not match the actual data type ({dtype})")
                    return

            # Continue with the rest of the processing
            null_counts = {col_name: employee.filter(col(col_name).isNull()).count() for col_name in employee.columns}
            for col_name, count in null_counts.items():
                print(f"Null count in {col_name}: {count}")
                
            count_duplicates = employee.groupBy(employee.columns).count().filter("count > 1")
            print("Duplicate rows count:")
            count_duplicates.show() 
            
            employee.printSchema()   

            today_date = datetime.now()
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))
            year = today_date.year
            month = today_date.month
            day = today_date.day
            hour = today_date.hour
            minute = today_date.minute
            second = today_date.second
            emp = 'employee'
            output_path = f"dbfs:/Landing/Silver/{emp}/{year}/{month}/{day}/{hour}/{minute}/{second}/"
            break
            
Employees(employee, Metadata)

# COMMAND ----------

