# Databricks notebook source
#############################################Main##############################################################

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *

df=spark.read.csv("dbfs:/FileStore/XyentaHolidays-2.csv",header=True,inferSchema=True)

# # Generate output paths
# Paths = "dbfs:/Project/Silver/XyentaHolidays/2024/3/20/2024-3-20/part-00000-tid-8022002276284061525-91ecdbe6-6b0c-4b19-a6e8-701e99e6ee9c-120-1-c000.snappy.parquet"
# # Read the source DataFrame
# df = spark.read.parquet(Paths)
SourceDF  = df.select("holiday", "date").distinct()
SourceDF = df.groupBy("holiday").agg(F.max("date").alias("date"))

# Display the DataFrame with maximum dates for each holiday
display(SourceDF)


# COMMAND ----------

targetDF=spark.sql("select * from dev.DimHoliday")
targetDF=targetDF.select("Holiday","Date")

# COMMAND ----------

new_records = SourceDF.join(targetDF,SourceDF["holiday"]  ==targetDF["Holiday"] , "left_anti").select(SourceDF["*"])
display(new_records)

# COMMAND ----------

existing_records=SourceDF.join(targetDF, SourceDF["holiday"]  ==targetDF["Holiday"], "inner").select(targetDF["*"])
display(existing_records)

# COMMAND ----------

combined=new_records.unionByName(existing_records)
display(combined)

# COMMAND ----------

combined.write.mode('overwrite').saveAsTable("dev.dimholiday")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimholiday

# COMMAND ----------

