# Databricks notebook source
# MAGIC %sql
# MAGIC create schema IF NOT EXISTS dev
# MAGIC
# MAGIC

# COMMAND ----------

from datetime import datetime
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day


# COMMAND ----------

dbutils.fs.rm("dbfs:/user", recurse=True)
dbutils.fs.rm("dbfs:/Project/Gold/", recurse=True)
dbutils.fs.rm("dbfs:/Project/DeltaTables/", recurse=True)



# COMMAND ----------

from datetime import datetime


today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day


sql_query = f'''
CREATE TABLE dev.DimManager (
  Pk_ManagerKey LONG GENERATED ALWAYS AS IDENTITY ,
  managerNo STRING ,
  managerName STRING,
  ActiveIndicator STRING,
  startDate TIMESTAMP,
  endDate TIMESTAMP
)
LOCATION  "dbfs:/Project/Gold/dev.dimmanager/{year}/{month}/{day}/"
'''
spark.sql(sql_query)

# COMMAND ----------

from datetime import datetime
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day


sql_query = f'''

CREATE TABLE dev.DimDesignation (
  Pk_DesignationKey LONG GENERATED ALWAYS AS IDENTITY,
  Designation STRING
)

LOCATION "dbfs:/Project/Gold/dev.dimdesignation/{year}/{month}/{day}"
'''
spark.sql(sql_query)

# COMMAND ----------

sql=f'''
CREATE TABLE dev.DimLeaveType(
    pk_LeaveTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
    LeaveType STRING
    
 
)
LOCATION "dbfs:/Project/Gold/dev.dimleavetype/{year}/{month}/{day}"'''
spark.sql(sql)

# COMMAND ----------

sql=f'''
CREATE TABLE  dev.DimEmployee(
  Pk_EmployeeTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
  pk_empid STRING,
  employeename STRING,
  ActiveIndicator STRING,
  startDate TIMESTAMP,
  endDate TIMESTAMP
)
LOCATION "dbfs:/Project/Gold/dev.dimemployee/{year}/{month}/{day}"'''
spark.sql(sql)

# COMMAND ----------

sql=f'''
CREATE TABLE dev.dimholiday(
  Pk_HolidayTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
  holiday STRING,
  date STRING
)
LOCATION "dbfs:/Project/Gold/dev.dimholiday/{year}/{month}/{day}"'''
spark.sql(sql)

# COMMAND ----------

# %sql
# create table Dev.DimDate(
#   PK_DateKey LONG GENERATED ALWAYS AS IDENTITY,
#   Date Integer,
#   Year integer,
#   Month integer,
#   Quater integer
  
# )
# LOCATION "dbfs:/Project/Gold/DimDate"

# COMMAND ----------

sql=f'''
create table  dev.TControlSCD1 (
  id int,
  LoadType string,
  SourceTableName string,
  SourceColumnNames string,
  AliasColumnNames string,
  IsAutoKey string,
  IsLogicColumn string,
  TargetTableName string,
  TargetColumnNames string,
  IsScd string
)

LOCATION "dbfs:/Project/Gold/dev.TControlSCD1/{year}/{month}/{day}"'''
spark.sql(sql)

# COMMAND ----------

# MAGIC
# MAGIC %sql 
# MAGIC INSERT into dev.tcontrolscd1 values 
# MAGIC (1, 'SCD1', 'EmployeeLoginDetails','', '','Y','','dev.dimdesignation','Pk_DesignationKey',''),
# MAGIC (2,'SCD1','EmployeeLoginDetails','designation','Designation','','Y','dev.dimdesignation','designation','Y'),
# MAGIC (3,'SCD1','Xyenta_Leaves_2022','','','Y','','dev.dimleavetype','pk_LeaveTypeKey',''),
# MAGIC (4,'SCD1','Xyenta_Leaves_2022','leavetype','LeaveType','','Y','dev.dimleavetype','leavetype','Y'),
# MAGIC (5,'SCD1','XyentaHolidays','','','Y','','dev.dimholiday','Pk_HolidayTypeKey',''),
# MAGIC (6,'SCD1','XyentaHolidays','holiday','holiday','','Y','dev.dimholiday','holiday','Y'),
# MAGIC (7,'SCD1','XyentaHolidays','date','date','','','dev.dimholiday','date','Y'),
# MAGIC (8, 'SCD2', '', '','', 'Y', '', 'dev.dimemployee',  'Pk_EmployeeType', ''),
# MAGIC (9, 'SCD2', 'EmployeeLoginDetails', 'pk_empid','Source_pk_empid', '', 'Y', 'dev.dimemployee',  'pk_empid', ''),
# MAGIC (10, 'SCD2', 'EmployeeLoginDetails', 'employeename','Source_employeename', '', '', 'dev.dimemployee',  'employeename', 'Y'),
# MAGIC (11,'SCD2','','','','Y','','dev.dimmanager','Pk_ManagerKey',''),
# MAGIC (12,'SCD2','Xyenta_Leaves_2022','managerno','Source_managerno','','Y',"dev.dimmanager",'managerno',''),
# MAGIC (13,'SCD2','Xyenta_Leaves_2022','managername','Source_managername','','','dev.dimmanager','managername','Y')
# MAGIC
# MAGIC

# COMMAND ----------

# sql=f'''
# create table  dev.TControlSCD2(
#   id int,
#   LoadType string,
#   SourceTableName string,
#   SourceColumnNames string,
#   AliasNameColumns string,
#   IsAutoKey string,
#   IsLogicColumn string,
#   TargetTableName string,
#   TargetColumnNames string,
#   IsScd string
# )
# LOCATION "dbfs:/Project/Gold/dev.TControlSCD2/{year}/{month}/{day}"'''
# spark.sql(sql)

# COMMAND ----------

# %sql
# INSERT INTO dev.TControlSCD2 VALUES
# (1, 'SCD2', '', '','', 'Y', '', 'dev.dimemployee',  'Pk_EmployeeType', ''),
# (2, 'SCD2', 'EmployeeLoginDetails', 'pk_empid','Source_pk_empid', '', 'Y', 'dev.dimemployee',  'pk_empid', ''),
# (3, 'SCD2', 'EmployeeLoginDetails', 'employeename','Source_employeename', '', '', 'dev.dimemployee',  'employeename', 'Y'),
# (4,'SCD2','','','','Y','','dev.dimmanager','Pk_ManagerKey',''),
# (5,'SCD2','Xyenta_Leaves_2022','managerno','Source_managerno','','Y',"dev.dimmanager",'managerno',''),
# (6,'SCD2','Xyenta_Leaves_2022','managername','Source_managername','','','dev.dimmanager','managername','Y')



# COMMAND ----------

