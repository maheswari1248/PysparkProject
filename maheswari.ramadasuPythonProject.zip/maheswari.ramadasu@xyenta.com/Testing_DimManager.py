# Databricks notebook source
###########################################CSV########################################################################

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day
SourceDF=spark.read.csv("dbfs:/FileStore/Xyenta_Leaves_2022-2.csv",header=True,inferSchema=True)
display(SourceDF)
# Generate output paths
# Paths = f"dbfs:/Project/Silver/Xyenta_Leaves_2022/{year}/{month}/{day}/{year}-{month}-{day}/"
# display(Paths)
# # Assuming joinDf and df_dimemployee are defined
# # Filter condition
# SourceDF = spark.read.parquet(Paths)
# SourceDF=SourceDF.select("managerno","managername").distinct()
SourceDF=SourceDF.select("Manager No","Manager Name").distinct()
SourceDF = SourceDF.filter((col("Manager No").isNotNull()) & (col("Manager Name").isNotNull()))
# # #CSV
# SourceDF = SourceDF.filter((col("managerno") != "unknown") & (col("managername") != "unknown"))
display(SourceDF)

# COMMAND ----------

targetTable=DeltaTable.forPath(spark,"dbfs:/Project/Gold/dev.dimmanager")
targetDF=targetTable.toDF()
joinDf = SourceDF.join(targetDF, (targetDF["ManagerNo"] == SourceDF["Manager No"])& (targetDF["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        SourceDF["Manager No"].alias("Source_managerno"),  
        SourceDF["Manager Name"].alias("Source_managername"), 
        targetDF["ManagerNo"].alias("Target_ManagerNo") ,
        targetDF["ManagerName"].alias("Target_ManagerName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )
joinDf.show()

# COMMAND ----------

#Filter
filterDf = joinDf.filter(xxhash64(joinDf.Source_managername) != xxhash64(joinDf.Target_ManagerName))
filterDf.show()

# COMMAND ----------

#merge
mergeDf = filterDf.withColumn("MERGEKEY", filterDf.Source_managerno)

# Display mergeDf
mergeDf.show()

# COMMAND ----------

#Dummy
dummyDf = filterDf.filter("Target_ManagerNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
dummyDf.show()

# COMMAND ----------

scdDf = mergeDf.union(dummyDf)

# Show scdDf
display(scdDf)

# COMMAND ----------



targetTable.alias("target").merge(
    source=scdDf.alias("source"),
    condition="target.ManagerNo = source.MERGEKEY and target.ActiveIndicator ='Y'"
).whenMatchedUpdate(
    set={
        "ActiveIndicator": "'N'",
        "endDate": F.current_date()
    }
).whenNotMatchedInsert(
    values={
        "ManagerNo": "source.Source_managerno",
        "ManagerName": "source.Source_managername",
        "ActiveIndicator": "'Y'",
        "startDate": F.current_date(),
        "endDate": F.lit(None)  # Using F.lit(None) to represent a null value
    }
).execute()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimmanager

# COMMAND ----------

#######################################csv###############################################################################################

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day
SourceDF=spark.read.csv("dbfs:/FileStore/Xyenta_Leaves_2022-1.csv",header=True,inferSchema=True)
SourceDF=SourceDF.select("Manager No","Manager Name").distinct()
SourceDF = SourceDF.filter((col("Manager No").isNotNull()) & (col("Manager Name").isNotNull()))
# # #CSV
display(SourceDF)

# COMMAND ----------

targetTable=DeltaTable.forPath(spark,"dbfs:/Project/Gold/dev.dimmanager")
targetDF=targetTable.toDF()
joinDf = SourceDF.join(targetDF, (targetDF["ManagerNo"] == SourceDF["Manager No"])& (targetDF["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        SourceDF["Manager No"].alias("Source_managerno"),  
        SourceDF["Manager Name"].alias("Source_managername"), 
        targetDF["ManagerNo"].alias("Target_ManagerNo") ,
        targetDF["ManagerName"].alias("Target_ManagerName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )
joinDf.show()

# COMMAND ----------

#Filter
filterDf = joinDf.filter(xxhash64(joinDf.Source_managername) != xxhash64(joinDf.Target_ManagerName))
filterDf.show()

# COMMAND ----------

#merge
mergeDf = filterDf.withColumn("MERGEKEY", filterDf.Source_managerno)

# Display mergeDf
mergeDf.show()

# COMMAND ----------

#Dummy
dummyDf = filterDf.filter("Target_ManagerNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
dummyDf.show()

# COMMAND ----------

scdDf = mergeDf.union(dummyDf)

# Show scdDf
display(scdDf)

# COMMAND ----------



targetTable.alias("target").merge(
    source=scdDf.alias("source"),
    condition="target.ManagerNo = source.MERGEKEY and target.ActiveIndicator ='Y'"
).whenMatchedUpdate(
    set={
        "ActiveIndicator": "'N'",
        "endDate": F.current_date()
    }
).whenNotMatchedInsert(
    values={
        "ManagerNo": "source.Source_managerno",
        "ManagerName": "source.Source_managername",
        "ActiveIndicator": "'Y'",
        "startDate": F.current_date(),
        "endDate": F.lit(None)  # Using F.lit(None) to represent a null value
    }
).execute()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimmanager

# COMMAND ----------

