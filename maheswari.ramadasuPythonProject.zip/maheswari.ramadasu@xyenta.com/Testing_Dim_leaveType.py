# Databricks notebook source
# MAGIC %sql
# MAGIC select * from dev.dimleavetype

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day
# Paths = f"dbfs:/Project/Silver/Xyenta_Leaves_2022/{year}/{month}/{day}/{year}-{month}-{day}/"
# display(Paths)
# SourceDF = spark.read.parquet(Paths)
# SourceDF=SourceDF.select("leavetype").distinct()
# SourceDF = SourceDF.filter((col("leavetype") != "unknown") )
SourceDF=spark.read.csv("dbfs:/FileStore/Xyenta_Leaves_2022-2.csv",header=True,inferSchema=True)
display(SourceDF)
SourceDF = SourceDF.select("Leave Type").distinct()
SourceDF = SourceDF.withColumnRenamed("Leave Type", "LeaveType")
SourceDF = SourceDF.filter(col("LeaveType").isNotNull())
#Target Table
targetDF=spark.sql("select * from dev.dimleavetype")
targetDF.show()
#NewRecords
new_records = SourceDF.join(targetDF,SourceDF["LeaveType"]  ==targetDF["LeaveType"] , "left_anti").select(SourceDF["*"])
display(new_records)
#existing_records
existing_records=SourceDF.join(targetDF, SourceDF["LeaveType"]  ==targetDF["LeaveType"], "inner").select(targetDF["*"])
existing_records=existing_records.select("LeaveType")
display(existing_records)
#union of both
combined=new_records.unionByName(existing_records)
display(combined)

#Saving in table
combined.write.mode('overwrite').saveAsTable("dev.dimleavetype")

# COMMAND ----------

targetDF=spark.sql("select * from dev.dimleavetype")
targetDF.show()


# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimleavetype

# COMMAND ----------

new_records = SourceDF.join(targetDF,SourceDF["leavetype"]  ==targetDF["LeaveType"] , "left_anti").select(SourceDF["*"])
display(new_records)

# COMMAND ----------

existing_records=SourceDF.join(targetDF, SourceDF["leavetype"]  ==targetDF["LeaveType"], "inner").select(targetDF["*"])

existing_records=existing_records.select("LeaveType")
display(existing_records)

# COMMAND ----------

combined=new_records.unionByName(existing_records)
display(combined)

# COMMAND ----------

combined.write.mode('overwrite').saveAsTable("dev.dimleavetype")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimleavetype

# COMMAND ----------

# combined.write.mode('overwrite').saveAsTable("dev.dimleavetype")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimleavetype

# COMMAND ----------

