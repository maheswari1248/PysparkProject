# Databricks notebook source
dbutils.fs.mkdirs("dbfs:/FileStore/Landing")



# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Gold")


# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project")

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Landing")

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Gold")

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Silver")

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Bronze")

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/Project/Metadata")

# COMMAND ----------

dbutils.fs.rm("dbfs:/Project/Bronze", recurse=True)


# COMMAND ----------

# Define sample data
data = []
columns = ["name", "age"]

# Create a DataFrame
df = spark.createDataFrame(data, schema=columns)

# Write DataFrame as a Delta table
df.write.format("delta").save("/path/to/delta_table")


# COMMAND ----------

display(dbutils.fs.ls("/Landing/Silver"))

# COMMAND ----------



# COMMAND ----------

# dbutils.fs.help()

dbutils.fs.mkdirs('Landing')

# COMMAND ----------

#dbutils.fs.cp('existing', 'target')
#Copying the csv("EmployeeLoginDetails.csv") from FileStore to the 
dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/EmployeeLoginDetails.csv","dbfs:/Landing/Bronze")



# COMMAND ----------

# copying the csv XyentaHolidays
dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/XyentaHolidays.csv","dbfs:/Landing/Bronze")

# COMMAND ----------

#copying the csv XyentaLeaves
dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/Xyenta_Leaves_2022.csv","dbfs:/Landing/Bronze")

# COMMAND ----------

#Creating the MetaData
dbutils.fs.mkdirs('dbfs:/Project/Metadata')

# COMMAND ----------

dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/EmployeeLoginDetails.csv","dbfs:/Project/Bronze")


# COMMAND ----------

dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/XyentaHolidays.csv","dbfs:/Project/Bronze")

# COMMAND ----------

#copying the csv XyentaLeaves to Lnading
dbutils.fs.cp("dbfs:/FileStore/Landing/Bronze/Xyenta_Leaves_2022.csv","dbfs:/Project/Bronze")

# COMMAND ----------

#Copying the Filestore to Metadata
#Metadata_colums
dbutils.fs.cp("dbfs:/FileStore/MetaData_Tables.csv", "dbfs:/Project/Metadata")




# COMMAND ----------

display(dbutils.fs.ls("/FileStore"))

# COMMAND ----------

#Copying the Filestore to Metadata
#Metadata_Tables


# COMMAND ----------

#Copying the Filestore to Metadata
#Metadata_Tables
dbutils.fs.cp("dbfs:/FileStore/Metadata_Colums.csv", "dbfs:/Landing/Metadata")

# COMMAND ----------

dbutils.fs.cp("dbfs:/FileStore/tcontrolscd.csv", "dbfs:/Project/Gold")

# COMMAND ----------

