# Databricks notebook source


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, sequence, current_date, date_add, year, month, dayofmonth



# Define the start and end dates
start_date = current_date()
end_date = date_add(start_date, 365)

# Create a sequence of dates from start_date to end_date
date_range_df = spark.range(1).select(explode(sequence(start_date, end_date)).alias("Date"))

# Extract year, month, and day from the Date column
result_df = date_range_df.select(
    year("Date").alias("Year"),
    month("Date").alias("Month"),
    dayofmonth("Date").alias("Date")  # Cast Day column to string type
)
result_df.show()
# Specify the path to the Delta table
delta_table_path = "dbfs:/Project/DeltaTables/DimDate"

# Save the result_df to the Delta table
result_df.write.mode("append").format("delta").save(delta_table_path)


# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from dev.dimdate

# COMMAND ----------



