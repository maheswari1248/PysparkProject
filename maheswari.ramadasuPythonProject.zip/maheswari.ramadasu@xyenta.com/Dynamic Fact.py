# Databricks notebook source
dbutils.fs.ls("/Project/Metadata/Metadata_Colums.csv")

# COMMAND ----------

s=spark.read.csv("/Project/Metadata/Metadata_Colums.csv",header=True)
display(s)

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema if not exists dev

# COMMAND ----------

# MAGIC %sql
# MAGIC create table dev.Fact_EmployeeActivity(
# MAGIC   Sno LONG GENERATED ALWAYS AS IDENTITY ,   
# MAGIC   FK_EmployeeKey long,
# MAGIC   FK_Designationkey long,
# MAGIC   AttendanceDate string,
# MAGIC   FirstInTime timestamp,
# MAGIC   LastOutTime timestamp,
# MAGIC   entryDate timestamp
# MAGIC )

# COMMAND ----------

