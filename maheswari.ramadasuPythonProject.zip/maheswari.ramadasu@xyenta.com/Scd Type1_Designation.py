# Databricks notebook source
# MAGIC %sql
# MAGIC create schema if not exists dev
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists dev.TControlSCD1

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dev.TControlSCD1(
# MAGIC   id int,
# MAGIC   LoadType string,
# MAGIC   SourceTableName string,
# MAGIC   SourceColumnNames string,
# MAGIC   AliasColumnNames string,
# MAGIC   IsAutoKey string,
# MAGIC   IsLogicColumn string,
# MAGIC   TargetTableName string,
# MAGIC   TargetColumnNames string,
# MAGIC   IsScd string
# MAGIC );

# COMMAND ----------

control_df=spark.sql("select * from dev.TControlSCD1")
control_df.show()

# COMMAND ----------

# MAGIC %sql 
# MAGIC INSERT into dev.tcontrolscd1 values 
# MAGIC (1, 'SCD1', 'EmployeeLoginDetails','', '','Y','','dev.dimdesignation','Pk_DesignationKey',''),
# MAGIC (2,'SCD1','EmployeeLoginDetails','designation','Designation','','Y','dev.dimdesignation','Designation','Y')
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.tcontrolscd1

# COMMAND ----------

from pyspark.sql.functions import *
tgt_table = control_df.filter(col('TargetTableName') == 'dev.dimdesignation')
tgt_cols = tgt_table.filter(col('IsAutoKey')!='Y').select('TargetColumnNames')

tgt_cols_str = tgt_cols.collect()[0][0]
print("Target_column_name",tgt_cols_str)

# COMMAND ----------

tgt_table_name  = tgt_table.select('TargetTableName').distinct().collect()[0][0]
print("Target Table Name",tgt_table_name)


# COMMAND ----------

src_table_name = tgt_table.filter(col('SourceTableName')!='').select('SourceTableName').distinct()
src_table_name = src_table_name.collect()[0][0]
print("SourceTableName",src_table_name)

# COMMAND ----------

scd_columns = tgt_table.filter(col("IsScd") == "Y").selectExpr("concat(TargetTableName, '.', TargetColumnNames, ' == x.', SourceColumnNames) AS scd_cols")

scd_columns.show(truncate=False)

# COMMAND ----------


logic_cols = tgt_table.filter(col("IsLogicColumn") == "Y").selectExpr("concat('y', '.', TargetColumnNames, ' == x.', AliasColumnNames) AS logic_col")

logic_cols.show(truncate = False)


# COMMAND ----------

logic_col_name = tgt_table.filter(col("IsLogicColumn") == "Y").select("TargetColumnNames").collect()[0][0]
print(logic_col_name)

# COMMAND ----------

logic_list = logic_cols.selectExpr("concat_ws(' AND ', collect_list(logic_col)) AS logic_col")

# logic_list.show(truncate = False)
# logic_list.show(truncate = False)
logic_col_list = logic_list.collect()[0][0]
print('logic_col_list : ',logic_col_list)

# COMMAND ----------

logic_list = logic_cols.selectExpr("concat_ws(' AND ', collect_list(logic_col)) AS logic_col")
display(logic_list)

# COMMAND ----------

print("AutoKey columnNames")

auto_col = tgt_table.filter(col('IsAutoKey')=='Y').select(col('TargetColumnNames')).collect()[0][0]
print(auto_col)

# COMMAND ----------

# stg_df = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/23/2024-3-23/part-00000-tid-7768668729365811326-06ac9b37-ebfa-42f6-af42-82ed01028cef-78-1-c000.snappy.parquet")
stg_df=spark.read.csv("dbfs:/FileStore/EmployeeLoginDetails-7.csv",header=True,inferSchema=True)
stg_df=stg_df.select("designation").distinct()

dim_df = spark.sql("""SELECT * FROM """ +tgt_table_name)
print("dim_Df exisiting table records")
dim_df.show()

print("check for new records...")

logic_col_list_expr = expr(logic_col_list) #'BrandName'
drop_columns_expr = expr(auto_col)
# print(logic_col_list_expr)
new_records = stg_df.alias('x').join(dim_df.alias('y'), logic_col_list_expr, 'left_anti')
print("new records....")
new_records.show()




# COMMAND ----------

updated_records = stg_df.alias('x').join(dim_df.alias('Y'), logic_col_list_expr, 'inner').select(dim_df['*']).drop(drop_columns_expr)

print("matching from src to target ")
updated_records.show()


# COMMAND ----------

combined_records = new_records.unionByName(updated_records).distinct()

combined_records.show()

combined_records.write.mode('overwrite').saveAsTable(f"{tgt_table_name}")
print("done")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimdesignation

# COMMAND ----------



# COMMAND ----------

