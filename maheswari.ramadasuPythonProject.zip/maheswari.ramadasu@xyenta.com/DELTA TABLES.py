# Databricks notebook source
data = [("John", 30), ("Alice", 35), ("Bob", 40)]
columns = ["name", "age"]

# Create a DataFrame
df = spark.createDataFrame(data, schema=columns)

# Write DataFrame as a Delta table
df.write.format("delta").save("/")

# COMMAND ----------

# Read Delta table
df_delta = spark.read.format("delta").load("/path/to/delta_table")
display(df_delta)


# COMMAND ----------

# Set configuration property to disable Delta format check
spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")


# COMMAND ----------

# MAGIC %sql
# MAGIC create table Dev.DimDate