# Databricks notebook source
# MAGIC %sql
# MAGIC create schema if not exists dev
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dev.TControlSCD1(
# MAGIC   id int,
# MAGIC   LoadType string,
# MAGIC   SourceTableName string,
# MAGIC   SourceColumnNames string,
# MAGIC   AliasColumnNames string,
# MAGIC   IsAutoKey string,
# MAGIC   IsLogicColumn string,
# MAGIC   TargetTableName string,
# MAGIC   TargetColumnNames string,
# MAGIC   IsScd string
# MAGIC );

# COMMAND ----------

control_df=spark.sql("select * from dev.TControlSCD1")
control_df.show()
dim_levaetype=spark.sql("select * from dev.dimleavetype")

# COMMAND ----------

# %sql 
# INSERT into dev.tcontrolscd1 values 
# (1, 'SCD1', 'EmployeeLoginDetails','', '','Y','','dev.dimdesignation','Pk_DesignationKey',''),
# (2,'SCD1','EmployeeLoginDetails','designation','Designation','','Y','dev.dimdesignation','Designation','Y'),
# (3,'SCD1','Xyenta_Leaves_2022','','','Y','','dev.dimleavetype','pk_LeaveTypeKey',''),
# (4,'SCD1','Xyenta_Leaves_2022','leavetype','LeaveType','','Y','dev.dimleavetype','LeaveType','Y')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.tcontrolscd1

# COMMAND ----------

from pyspark.sql.functions import *
tgt_table = control_df.filter(col('TargetTableName') == 'dev.dimleavetype')
tgt_cols = tgt_table.filter(col('IsAutoKey')!='Y').select('TargetColumnNames')

tgt_cols_str = tgt_cols.collect()[0][0]
print("Target_column_name",tgt_cols_str)

# COMMAND ----------

tgt_table_name  = tgt_table.select('TargetTableName').distinct().collect()[0][0]
print("Target Table Name",tgt_table_name)


# COMMAND ----------

src_table_name = tgt_table.filter(col('SourceTableName')!='').select('SourceTableName').distinct()
src_table_name = src_table_name.collect()[0][0]
print("SourceTableName",src_table_name)

# COMMAND ----------

scd_columns = tgt_table.filter(col("IsScd") == "Y").selectExpr("concat(TargetTableName, '.', TargetColumnNames, ' == x.', SourceColumnNames) AS scd_cols")

scd_columns.show(truncate=False)

# COMMAND ----------


logic_cols = tgt_table.filter(col("IsLogicColumn") == "Y").selectExpr("concat('y', '.', TargetColumnNames, ' == x.', AliasColumnNames) AS logic_col")

logic_cols.show(truncate = False)


# COMMAND ----------

logic_col_name = tgt_table.filter(col("IsLogicColumn") == "Y").select("TargetColumnNames").collect()[0][0]
print(logic_col_name)

# COMMAND ----------

logic_list = logic_cols.selectExpr("concat_ws(' AND ', collect_list(logic_col)) AS logic_col")

# logic_list.show(truncate = False)
# logic_list.show(truncate = False)
logic_col_list = logic_list.collect()[0][0]
print('logic_col_list : ',logic_col_list)

# COMMAND ----------

logic_list = logic_cols.selectExpr("concat_ws(' AND ', collect_list(logic_col)) AS logic_col")
display(logic_list)

# COMMAND ----------

print("AutoKey columnNames")

auto_col = tgt_table.filter(col('IsAutoKey')=='Y').select(col('TargetColumnNames')).collect()[0][0]
print(auto_col)

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *
stg_df=spark.read.csv("dbfs:/FileStore/Xyenta_Leaves_2022-2.csv",header=True,inferSchema=True)
stg_df=stg_df.select("Leave Type").distinct()
stg_df= stg_df.filter((col("LeavetType").isNotNull()) )
display(stg_df)

# COMMAND ----------



dim_df = spark.sql("""SELECT * FROM """ +tgt_table_name)
print("dim_Df exisiting table records")
dim_df.show()

print("check for new records...")

logic_col_list_expr = expr(logic_col_list) #'BrandName'
drop_columns_expr = expr(auto_col)
# print(logic_col_list_expr)
new_records = stg_df.alias('x').join(dim_df.alias('y'), logic_col_list_expr, 'left_anti')
print("new records....")
new_records.show()


# COMMAND ----------

updated_records = stg_df.alias('x').join(dim_df.alias('Y'), logic_col_list_expr, 'inner').select(dim_df['*']).drop(drop_columns_expr)

print("matching from src to target ")
updated_records.show()


# COMMAND ----------

combined_records = new_records.unionByName(updated_records).distinct()

combined_records.show()

combined_records.write.mode('overwrite').saveAsTable(f"{tgt_table_name}")
print("done")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dev.dimleavetype

# COMMAND ----------

