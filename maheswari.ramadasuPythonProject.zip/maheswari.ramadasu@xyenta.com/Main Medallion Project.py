# Databricks notebook source

##########################Landing_to_Bronze#############################################
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from datetime import datetime
import os

# List of paths
Paths = dbutils.fs.ls('/Project/Landing')
path_list = [item.path for item in Paths]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame
df = spark.createDataFrame([(path,) for path in path_list], schema)

# Show DataFrame
df.show(truncate=False)

# Define function to convert Landing to Bronze
def Landing_To_Bronze(df):
    for row in df.collect():
        file_path = row.path
        file_name = os.path.basename(file_path).split(".")[0]
        df = spark.read.csv(file_path, header=True)
        today_date = datetime.now()
        year = today_date.year
        month = today_date.month
        day = today_date.day

    # Define the output path
        df.write.csv(f"dbfs:/Project/Bronze/{file_name}/{year}/{month}/{day}/{year}-{month}-{day}", mode="overwrite",header=True)

# Apply the function
Landing_To_Bronze(df)


# COMMAND ----------

# MAGIC %md BRONZE TO SILVER

# COMMAND ----------

from datetime import datetime
import os

from pyspark.sql.types import *
from pyspark.sql.functions import *


# Function to process DataFrame
def process_dataframe(df, metadata, folder_name, file_name):
    # Convert column names to lowercase and remove spaces
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])
    
    # Check if the columns and their data types match with metadata
    metadata_columns = metadata.select('Columns').collect()
    metadata_Staging = metadata.select('StagingNames').collect()
    for row, staging_name_row in zip(metadata_columns, metadata_Staging):
        source_column = row[0]
        staging_name = staging_name_row[0]
        if source_column and staging_name in df.columns:
            metadata_row = metadata.filter(metadata.Columns == source_column).collect()
            if metadata_row:
                metadata_row = metadata_row[0]
                source_datatype = metadata_row.SourceDataType
                target_datatype = metadata_row.TargetDataType
                target_data_type = df.select(source_column).dtypes[0][1]
                if target_data_type != target_datatype:
                    print(f"Error: Target data type of column '{source_column}' ({target_datatype}) does not match the actual data type ({target_data_type})")
                    error_msg = f"Error: Target data type of column '{source_column}' ({target_datatype}) does not match the actual data type ({target_data_type})"
                    raise ValueError(error_msg)
            else:
                print(f"Error: Column '{source_column}' not found in metadata.")
                # return
        
    # Drop any rows with missing values
    for col_name in df.columns:
        if df.schema[col_name].dataType == IntegerType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit(0)).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == StringType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("unknown")).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == DateType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("unknown")).otherwise(df[col_name]))
        
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()
    display(df)
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day

    # Define the output path
    output_path = f"dbfs:/Project/Silver/{folder_name}/{year}/{month}/{day}/{year}-{month}-{day}/"
    
    # Write the DataFrame to the output path
    df.write.mode("overwrite").parquet(output_path)
    
    return df

# Function to dynamically rename DataFrame columns
def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# Retrieve paths from Landing area
Paths_landing = dbutils.fs.ls('/Project/Landing')
path_list_landing = [item.path for item in Paths_landing]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame from landing paths
df_landing = spark.createDataFrame([(path,) for path in path_list_landing], schema)



# Process each file in Landing area
for row in df_landing.collect():
    file_path = row.path
    file_name = os.path.basename(file_path).split(".")[0]
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day
    
 
    formatted_path = f"/Project/Bronze/{file_name}/{year}/{month}/{day}/{year}-{month}-{day}"
 
    Paths = dbutils.fs.ls(formatted_path)
    path_list = [item.path for item in Paths]


    schema = StructType([StructField("path", StringType(), True)])


    df = spark.createDataFrame([(path,) for path in path_list], schema)
   
    display(df)

# Function to convert Bronze to Silver
def Bronze_To_Silver(df):
    for row in df.collect():
        Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)
        file_path = row.path
        file_name = file_path.split("/")[-1].split(".")[0]
        df = spark.read.csv(file_path, header=True, inferSchema=True)
        process_dataframe(df, Metadata, file_name, file_name)
        
# Convert Bronze to Silver
Bronze_To_Silver(df_landing)



# COMMAND ----------

# MAGIC %md DATE Comparison

# COMMAND ----------

def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# Retrieve paths from Landing area
Paths_landing = dbutils.fs.ls('/Project/Landing')
path_list_landing = [item.path for item in Paths_landing]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame from landing paths
df_landing = spark.createDataFrame([(path,) for path in path_list_landing], schema)

filenames = ['Xyenta_Leaves_2022', 'EmployeeLoginDetails']

def datevalidation(filename):
    try:
        df = spark.read.csv(f"dbfs:/Project/Landing/{filename}.csv", header=True, inferSchema=True)
        # display(df)
        
        # Read metadata
        Metadata = spark.read.csv('dbfs:/FileStore/Metadata_Colums-2.csv', header=True)
        display(Metadata)
        # Filter metadata for relevant columns filename
        ref_filter = Metadata.filter(col('StagingNames') == filename)
        display(ref_filter)
        
        IsDatecompare = ref_filter.filter(col('IsDate')=='Y')
        print("ISCOMPARE")
        display(IsDatecompare)
        
        for row in IsDatecompare.collect():
            date_column = row['Columns']
            format_check = 'dd MMM yyyy'
            print("hello")
            dfs = df.withColumn(
                'bad_record',
                when(col(date_column).isNull(), "False")
                .when(to_date(col(date_column), format_check).isNotNull(), "True")
                .otherwise("False")
            )
            # display(dfs)
            
            bad_records_df = dfs.filter(col('bad_record') == "False")
            good_records_df = dfs.filter(col('bad_record') == "True")

            bad_record_df_count = bad_records_df.count()
            print(bad_record_df_count)
            display(bad_records_df)
            good_records_df_count = good_records_df.count()
            display(good_records_df)

            if bad_record_df_count > 0 :
                print("entered into bad_records...")
                bad_path = f"dbfs:/Project/BadRecords/{filename}-DateMissmatched/{dt_str}/"
                bad_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(bad_path)
                print("written to bad path")
            
            if good_records_df_count > 0:
                print("entered into good_records...")
                good_path = f"dbfs:/Project/Silver/{filename}/{dt_str}/"
                good_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(good_path)
                print("done written to gold path")

        else : 
            print("No date column found..")

    except Exception as e:
        print(f"An error occurred while processing the datevalidation method : {str(e)}")    

datevalidation(filenames)


# COMMAND ----------

# MAGIC %md DYNAMIC SCDTYPE 1

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *

# Get current timestamp
today_date = datetime.now()

# Extract date components
year = today_date.year
month = today_date.month
day = today_date.day

Paths = [
    f"dbfs:/Project/Silver/EmployeeLoginDetails/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/Xyenta_Leaves_2022/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/XyentaHolidays/{year}/{month}/{day}/{year}-{month}-{day}/"
]
control_df = spark.sql("select * from dev.tcontrolscd1")

def scdtype1(paths, control_df, target_table_name):
    try:
        dim_df = spark.sql(f"SELECT * FROM {target_table_name}")
        dim_df.show()
        tgt_table = control_df.filter(col('TargetTableName') == target_table_name)
        tgt_cols_row = tgt_table.filter(col('IsAutoKey') != 'Y').select('TargetColumnNames').collect()
        tgt_cols = [col_name.TargetColumnNames for col_name in tgt_cols_row]  # Extracting column names from Row objects
        tgt_table_name = tgt_table.select('TargetTableName').distinct().collect()[0][0]
        print("Target Table Name:", tgt_table_name)
        print("Target Column Names:")
        print(tgt_cols)
        src_table_name = tgt_table.filter(col('SourceTableName') != '').select('SourceTableName').distinct()
        src_table_name = src_table_name.collect()[0][0]
        print("SourceTableName:", src_table_name)
        scd_columns = tgt_table.filter(col("IsScd") == "Y").selectExpr("concat(TargetTableName, '.', TargetColumnNames, ' == x.', SourceColumnNames) AS scd_cols")
        scd_columns.show(truncate=False)
        logic_cols = tgt_table.filter(col("IsLogicColumn") == "Y").selectExpr("concat('y', '.', TargetColumnNames, ' == x.', AliasColumnNames) AS logic_col")
        logic_cols.show(truncate=False)
        logic_col_name = tgt_table.filter(col("IsLogicColumn") == "Y").select("TargetColumnNames").collect()[0][0]
        print(logic_col_name)
        logic_list = logic_cols.selectExpr("concat_ws(' AND ', collect_list(logic_col)) AS logic_col")
        logic_col_list = logic_list.collect()[0][0]
        print('logic_col_list : ', logic_col_list)
        print("AutoKey columnNames:")
        auto_col = tgt_table.filter(col('IsAutoKey') == 'Y').select(col('TargetColumnNames')).collect()[0][0]
        print(auto_col)
        for path in paths:
            sourceDF = spark.read.parquet(path)
            Source_table_name = path.split("/")[-6]
            if Source_table_name == src_table_name:
                stg_df = sourceDF.select(*tgt_cols).distinct() 
                display(stg_df)
                print("check for new records...")
                logic_col_list_expr = expr(logic_col_list)
                drop_columns_expr = expr(auto_col)
                print(logic_col_list_expr)
                new_records = stg_df.alias('x').join(dim_df.alias('y'), logic_col_list_expr, 'left_anti')
                print("new records....")
                new_records.show()
                updated_records = stg_df.alias('x').join(dim_df.alias('Y'), logic_col_list_expr, 'inner').select(dim_df['*']).drop(drop_columns_expr)
                print("matching from src to target ")
                updated_records.show()
                combined_records = new_records.unionByName(updated_records)
                for col_name in combined_records.columns:
                    combined_records = combined_records.filter(col(col_name)!='unknown').distinct()
                    # Show the filtered DataFrame
                    combined_records.show()
                    combined_records.write.mode('overwrite').saveAsTable(f"{tgt_table_name}")
                    print("done")
    except Exception as e:
        print("An error occurred:", str(e))

scdtype1(Paths, control_df, "dev.dimleavetype")
