# Databricks notebook source


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------


from pyspark.sql import functions as F
from pyspark.sql.functions import *
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")

# Select relevant columns from the employee login details data and rename 'employeename'
stg_df = df_employee.select('pk_empid', F.col('employeename').alias('Employee Name')).distinct()
 
# Load DimEmployees table from the database
dim_df = spark.sql("SELECT * FROM DimEmployee")
 
dim_df.show()
#Identify updates and set end date for existing records
update_df = stg_df.join(
    dim_df,
    (stg_df["pk_empid"] == dim_df["EmployeeNo"]),
    "inner"
) \
    .filter( (stg_df["Employee Name"] != F.col("EmployeeName"))) \
    .filter(F.col("ActiveIndicator")=='Y') \
    .select(
        dim_df["*"]
       
    ) \
    .withColumn("endDate", F.current_date()) \
    .withColumn("ActiveIndicator", F.lit("N"))

update_df=update_df.select("EmployeeNo","EmployeeName","ActiveIndicator","startDate","endDate")
update_df.show()
 
# # Identify new records and prepare for insertion
comparison_df = stg_df.join(
    dim_df,
    stg_df["pk_empid"] == dim_df["EmployeeNo"],
    'left_anti'
).select(
    stg_df["pk_empid"].alias("EmployeeNo"),
    stg_df["Employee Name"].alias("EmployeeName"),
    F.lit('Y').alias("ActiveIndicator"),
    F.current_date().alias('startDate'),
    F.lit('9999-12-31').alias('endDate')
)
 
comparison_df.show()
updated_records_df = stg_df.join(
    update_df.select("EmployeeNo"),
    on=stg_df["pk_empid"] == update_df["EmployeeNo"],
    how="inner"
).select(
    stg_df["pk_empid"].alias("EmployeeNo"),
    stg_df["Employee Name"].alias("EmployeeName"),
    F.lit('Y').alias("ActiveIndicator"),
    F.current_date().alias("startDate"),
    F.lit("9999-12-31").alias("endDate")
)
updated_records_df.show()



updated_records_df=updated_records_df.withColumn("endDate", to_timestamp("endDate"))
updated_records_df.printSchema()
comparison_df = comparison_df.withColumn("endDate", to_timestamp("endDate"))

comparison_df.printSchema()

# COMMAND ----------

merge_up = update_df.unionByName(updated_records_df)

# COMMAND ----------

merge_up.show()

# COMMAND ----------



# COMMAND ----------

merge_up.show()

# COMMAND ----------




# COMMAND ----------

Final = merge_up.unionByName(comparison_df)

# COMMAND ----------

Final.show()

# COMMAND ----------

Final.write.mode('append').saveAsTable("DimEmployee")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Dimemployee

# COMMAND ----------

stg_df=spark.read.csv("dbfs:/FileStore/XyentaHolidays-1.csv")
stg_df.show()

# COMMAND ----------

################################################CSV#################################################################

# COMMAND ----------


from pyspark.sql import functions as F
from pyspark.sql.functions import *
#df_employee = spark.read.csv("dbfs:/FileStore/EmployeeLoginDetails-3.csv",header=True,inferSchema=True)
SourceDF=spark.read.csv("dbfs:/FileStore/EmployeeLoginDetails-5.csv",header=True,inferSchema=True)
stg_df=SourceDF.select("PK_EmpID","Employee Name").distinct()
stg_df.show()
 
# # Load DimEmployees table from the database
dim_df = spark.sql("SELECT * FROM dev.DimEmployee")
 
dim_df.show()


# COMMAND ----------

update_df = stg_df.join(
    dim_df,
    (stg_df["PK_empid"] == dim_df["EmployeeNo"]),
    "inner"
) \
    .filter( (stg_df["Employee Name"] != F.col("EmployeeName"))) \
    .filter(F.col("ActiveIndicator")=='Y') \
    .select(
        dim_df["*"]
       
    ) \
    .withColumn("endDate", F.current_date()) \
    .withColumn("ActiveIndicator", F.lit("N"))

update_df=update_df.select("EmployeeNo","EmployeeName","ActiveIndicator","startDate","endDate")
update_df.show()


# COMMAND ----------

# # # Identify new records and prepare for insertion
comparison_df = stg_df.join(
    dim_df,
    stg_df["PK_EmpID"] == dim_df["EmployeeNo"],
    'left_anti'
).select(
    stg_df["PK_EmpID"].alias("EmployeeNo"),
    stg_df["Employee Name"].alias("EmployeeName"),
    F.lit('Y').alias("ActiveIndicator"),
    F.current_date().alias('startDate'),
    F.lit('9999-12-31').alias('endDate')
)

# COMMAND ----------

updated_records_df=updated_records_df.withColumn("endDate", to_timestamp("endDate"))
updated_records_df.printSchema()
comparison_df = comparison_df.withColumn("endDate", to_timestamp("endDate"))

comparison_df.printSchema()

# COMMAND ----------

merge_up = update_df.unionByName(updated_records_df)

# COMMAND ----------

merge_up.show()

# COMMAND ----------

Final = merge_up.unionByName(comparison_df)

# COMMAND ----------

Final.show()

# COMMAND ----------

