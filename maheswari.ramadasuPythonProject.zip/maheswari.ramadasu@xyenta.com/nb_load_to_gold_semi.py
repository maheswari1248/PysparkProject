# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F

# COMMAND ----------

# dbutils.fs.mkdirs('Gold-Semi')
# dbutils.fs.ls('/FileStore/')
meta_path = 'dbfs:/FileStore/MetaData_Tables-1.csv'

def load_to_gold_semi(meta_path, gold_Semi_path):
    try:
        df = spark.read.format('csv').option('Header', 'True').option('inferSchema', 'True').load(meta_path)

        for x in df.collect():
            table = x['TableName']
            schema_name = x['Schema']

    except Exception as e:
        print(f'An error occur while processing load_to_gold_semi ::', {str(e)})

# COMMAND ----------

# MAGIC %run "/Users/maheswari.ramadasu@xyenta.com/Nb_Landing_To_Bronze"
# MAGIC

# COMMAND ----------

# MAGIC %run "/Users/maheswari.ramadasu@xyenta.com/Nb_Bronze_To Silver"

# COMMAND ----------

