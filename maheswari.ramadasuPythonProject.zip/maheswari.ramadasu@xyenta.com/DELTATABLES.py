# Databricks notebook source
# MAGIC %sql
# MAGIC create schema IF NOT EXISTS dev
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE dev.DimManager (
# MAGIC   Pk_ManagerKey LONG GENERATED ALWAYS AS IDENTITY ,
# MAGIC   ManagerNo STRING ,
# MAGIC   ManagerName STRING,
# MAGIC   ActiveIndicator STRING,
# MAGIC   startDate TIMESTAMP,
# MAGIC   endDate TIMESTAMP
# MAGIC )
# MAGIC LOCATION  "dbfs:/Project/DeltaTables/dev.dimmanager"

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS dev.DimManager;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE TABLE dev.DimDesignation (
# MAGIC   Pk_DesignationKey LONG GENERATED ALWAYS AS IDENTITY,
# MAGIC   Designation STRING
# MAGIC )
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS dev.DimDesigation

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE dev.DimLeaveType(
# MAGIC     pk_LeaveTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
# MAGIC     LeaveType STRING
# MAGIC     
# MAGIC  
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE  dev.DimEmployee(
# MAGIC   Pk_EmployeeTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
# MAGIC   EmployeeNo STRING,
# MAGIC   EmployeeName STRING,
# MAGIC   ActiveIndicator STRING,
# MAGIC   startDate TIMESTAMP,
# MAGIC   endDate TIMESTAMP
# MAGIC )
# MAGIC LOCATION "dbfs:/Project/DeltaTables/dev.dimemployee"

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema if not exists dev

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE dev.DimHoliday(
# MAGIC   Pk_HolidayTypeKey LONG GENERATED ALWAYS AS IDENTITY ,
# MAGIC   Holiday STRING,
# MAGIC   Date TIMESTAMP
# MAGIC )
# MAGIC

# COMMAND ----------




# COMMAND ----------

# MAGIC %sql
# MAGIC create schema IF NOT EXISTS Dev

# COMMAND ----------

# MAGIC %sql
# MAGIC create table Dev.DimDate(
# MAGIC   PK_DateKey LONG GENERATED ALWAYS AS IDENTITY,
# MAGIC   Date Integer,
# MAGIC   Year integer,
# MAGIC   Month integer
# MAGIC )
# MAGIC LOCATION "dbfs:/Project/DeltaTables/DimDate"

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists dev.dimdate

# COMMAND ----------

