# Databricks notebook source
import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_timestamp
from datetime import datetime

def process_dataframe(df, metadata, folder_name):
    # Convert column names to lowercase
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

    
    # Drop any rows with missing values
    df = df.na.drop()
    
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()

    # Get current timestamp
    today_date = datetime.now()
    timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))
    year = today_date.year
    month = today_date.month
    day = today_date.day
    hour = today_date.hour
    minute = today_date.minute
    second = today_date.second

    #Define the output path
    output_path = f"dbfs:/Landing/Silver/{folder_name}/{year}/{month}/{day}/{hour}/{minute}/{second}/"

    # Check if the output path exists
    if os.path.exists(output_path):
        print("Output path already exists, reading from existing path...")
        df.write.mode("overwrite").parquet(output_path)
        df.printSchema()
    else:
        print("Output path does not exist, creating the path...")
        df.write.mode("overwrite").parquet(output_path)

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True, inferSchema=True)
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)



# Assuming 'employee', 'XyentaHolidays', and 'Xyenta_Leaves' are your DataFrames

# Process each DataFrame
process_dataframe(employee, Metadata, "Employee")
process_dataframe(XyentaHolidays, Metadata, "XyentaHolidays")
process_dataframe(Xyenta_Leaves, Metadata, "XyentaLeaves")


# COMMAND ----------

#Employee Parquet Validation
output_employee_parquet="dbfs:/Project/Silver/Employee/2024/3/15/2024-3-15/part-00000-tid-6544618304897452305-a2e51a74-6022-4ae8-be72-f4ca7a1dc9f6-124-1-c000.snappy.parquet"
s=spark.read.parquet(output_employee_parquet)
# display(s)
# Check for null values
null_counts = {col_name: s.filter(s[col_name].isNull()).count() for col_name in s.columns}
for col_name, count in null_counts.items():
    print(f"Null count in {col_name}: {count}")
count_duplicates = s.groupBy(s.columns).count().filter("count > 1")
print("Duplicates count:")
count_duplicates.show()
s.printSchema()
display(s)

# COMMAND ----------

#XyentaHolidays
o='dbfs:/Project/Silver/XyentaHolidays/2024/3/15/2024-3-15/part-00000-tid-7450986871298291422-f85748aa-c2e1-4d5b-aba0-c57c123b207c-306-1-c000.snappy.parquet'
s=spark.read.parquet(o)
display(s)
null_counts = {col_name: s.filter(s[col_name].isNull()).count() for col_name in s.columns}
for col_name, count in null_counts.items():
    print(f"Null count in {col_name}: {count}")
count_duplicates = s.groupBy(s.columns).count().filter("count > 1")
print("Duplicates count:")
count_duplicates.show()
s.printSchema()

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/Project/Silver"))


# COMMAND ----------

#XyentaLeaves
o='dbfs:/Project/Bronze/Xyenta_Leaves_2022/part-00000-tid-6456751007690805382-ca71a89a-8ea8-4fb8-ae72-4bbd2a48a517-96-1-c000.csv'
s=spark.read.parquet(o)
display(s)
null_counts = {col_name: s.filter(s[col_name].isNull()).count() for col_name in s.columns}
for col_name, count in null_counts.items():
    print(f"Null count in {col_name}: {count}")
count_duplicates = s.groupBy(s.columns).count().filter("count > 1")
print("Duplicates count:")
count_duplicates.show()
s.printSchema()



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------


###################Main################################################

import os
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_timestamp
from datetime import datetime

def process_dataframe(df, metadata, folder_name):
    # Convert column names to lowercase
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day
    hour = today_date.hour
    minute = today_date.minute
    second = today_date.second

    for row in metadata.collect():
        source_columns = row['Columns']
        source_datatype = row['SourceDataType']
        target_datatype = row['TargetDataType']

        if source_columns in df.columns:
            # Check if target data type matches the data type of employee columns
            target_data_types = df.select(source_columns).dtypes
            for col_name, dtype in target_data_types:
                if dtype != target_datatype:
                    print(f"Error: Target data type of column {source_columns} ({target_datatype}) does not match the actual data type ({dtype})")
                    return

    
            # Drop any rows with missing values
            df = df.na.drop()
                
            # Drop duplicate rows
            df = df.dropDuplicates()
            

            # Check for null values
            null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
            for col_name, count in null_counts.items():
                 print(f"Null count in {col_name}: {count}")

            # Check for duplicate rows
            count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
            print("Duplicates count:")
            count_duplicates.show()

            # Print schema
            df.printSchema()

            # Get current timestamp
            timestamp_now = to_timestamp(today_date.strftime("%Y-%m-%d %H:%M:%S"))
          
            # Define the output path
            output_path = f"dbfs:/Landing/Silver/{folder_name}/{timestamp_now}/"
            if os.path.exists(output_path):
                print("Output path already exists, reading from existing path...")
                df = spark.read.parquet(output_path)
                df.printSchema()
            else:
                print("Output path does not exist, creating the path...")
                df.write.mode("overwrite").parquet(output_path)
          
            
            break

employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True, inferSchema=True)
Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True, inferSchema=True)
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)

# Assuming 'employee', 'XyentaHolidays', and 'Xyenta_Leaves' are your DataFrames

# Process each DataFrame
print("Employee")
process_dataframe(employee, Metadata, "Employee")
print("################################")
print("XyentaHolidays")
process_dataframe(XyentaHolidays, Metadata, "XyentaHolidays")
print("################################")
print("XyentaLeaves")
process_dataframe(Xyenta_Leaves, Metadata, "XyentaLeaves")


# COMMAND ----------



# COMMAND ----------

########MAIN SILVERLANDING##########################################################

from datetime import datetime
import os
from pyspark.sql.types import *
from pyspark.sql.functions import *

def process_dataframe(df, metadata, folder_name, file_name):
    # Convert column names to lowercase and remove spaces
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])
    
    # Check if the columns and their data types match with metadata
    metadata_columns = metadata.select('Columns').collect()
    metadata_Staging = metadata.select('StagingNames').collect()
    for row, staging_name_row in zip(metadata_columns, metadata_Staging):
        source_column = row[0]
        staging_name = staging_name_row[0]
        if source_column and staging_name in df.columns:
            metadata_row = metadata.filter(metadata.Columns == source_column).collect()
            if metadata_row:
                metadata_row = metadata_row[0]
                source_datatype = metadata_row.SourceDataType
                target_datatype = metadata_row.TargetDataType
                target_data_type = df.select(source_column).dtypes[0][1]
                if target_data_type != target_datatype:
                    print(f"Error: Target data type of column '{source_column}' ({target_datatype}) does not match the actual data type ({target_data_type})")
                    return
            else:
                print(f"Error: Column '{source_column}' not found in metadata.")
                return
        
    # Drop any rows with missing values
    df = df.na.drop()
    
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()

    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day

    # Define the output path
    output_path = f"dbfs:/Project/Silver/{folder_name}/{year}/{month}/{day}/{year}-{month}-{day}/"
    
    # Write the DataFrame to the output path
    df.write.mode("overwrite").parquet(output_path)
    
    return df

# Function to dynamically rename DataFrame columns
def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# Reading the CSVs
employee = spark.read.csv("dbfs:/Project/Bronze/EmployeeLoginDetails/part-00000-tid-7084095005490169454-4e9ac629-2fdc-47ee-94ad-8c2f9322abec-90-1-c000.csv", header=True, inferSchema=True)
XyentaHolidays = spark.read.csv("dbfs:/Project/Bronze/XyentaHolidays/part-00000-tid-7861014531116313573-5330eda2-db61-4dcb-8ad2-2d3c093c53d8-93-1-c000.csv",header=True, inferSchema=True)
Xyenta_Leaves = spark.read.csv("dbfs:/Project/Bronze/Xyenta_Leaves_2022/part-00000-tid-6456751007690805382-ca71a89a-8ea8-4fb8-ae72-4bbd2a48a517-96-1-c000.csv", header=True, inferSchema=True)

# Check the length of each DataFrame
employee_count = len(employee.columns)

employee = rename_columns(employee)
XyentaHolidays_count = len(XyentaHolidays.columns)

XyentaLeaves_count = len(Xyenta_Leaves.columns)-3

XyentaHolidays = rename_columns(XyentaHolidays)
Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)

Metadata_count = Metadata.select('Columns').count()
# Extract column names from the metadata DataFrame
metadata_columns = [row.Columns for row in Metadata.collect()]
# Process each DataFrame if its length is greater than zero
Total = employee_count + XyentaHolidays_count + XyentaLeaves_count

if Total == Metadata_count:
    process_dataframe(employee, Metadata, "Employee", "EmployeeLoginDetails")
    process_dataframe(XyentaHolidays, Metadata, "XyentaHolidays", "XyentaHolidays")
    process_dataframe(Xyenta_Leaves, Metadata, "XyentaLeaves", "Xyenta_Leaves_2022")
else:
    print("Error: Column counts or column names do not match.")
print(f"DataFrame column count: {Total}, Metadata column count: {Metadata.count()}")


# COMMAND ----------

display(dbutils.fs.ls("dbfs:/Project/Bronze"))



# COMMAND ----------


######Dynamic Silver Landing############################################
from datetime import datetime
import os
from pyspark.sql.types import *
from pyspark.sql.functions import *

from pyspark.sql.functions import lit, when

def process_dataframe(df, metadata, folder_name, file_name):
    # Convert column names to lowercase and remove spaces
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])
    
    # Check if the columns and their data types match with metadata
    metadata_columns = metadata.select('Columns').collect()
    metadata_Staging = metadata.select('StagingNames').collect()
    for row, staging_name_row in zip(metadata_columns, metadata_Staging):
        source_column = row[0]
        staging_name = staging_name_row[0]
        if source_column and staging_name in df.columns:
            metadata_row = metadata.filter(metadata.Columns == source_column).collect()
            if metadata_row:
                metadata_row = metadata_row[0]
                source_datatype = metadata_row.SourceDataType
                target_datatype = metadata_row.TargetDataType
                target_data_type = df.select(source_column).dtypes[0][1]
                if target_data_type != target_datatype:
                    print(f"Error: Target data type of column '{source_column}' ({target_datatype}) does not match the actual data type ({target_data_type})")
                    return
            else:
                print(f"Error: Column '{source_column}' not found in metadata.")
                return
        
    # Drop any rows with missing values
    for col_name in df.columns:
        if df.schema[col_name].dataType == IntegerType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit(0)).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == StringType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("unknown")).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == DateType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("unknown")).otherwise(df[col_name]))
        
    
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()
    display(df)
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day

    # Define the output path
    output_path = f"dbfs:/Project/Silver/{folder_name}/{year}/{month}/{day}/{year}-{month}-{day}/"
    
    # Write the DataFrame to the output path
    df.write.mode("overwrite").parquet(output_path)
    
    return df


# Function to dynamically rename DataFrame columns
def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

Paths = dbutils.fs.ls('/Project/Bronze')
path_list = [item.path for item in Paths]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame
df = spark.createDataFrame([(path,) for path in path_list], schema)

# Show DataFrame
df.show(truncate=False)

def Bronze_To_Silver(df):
    for row in df.collect():
        Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)
        file_path = row.path
        file_name = os.path.basename(os.path.normpath(file_path))
        df = spark.read.csv(file_path, header=True, inferSchema=True)
        process_dataframe(df, Metadata, file_name,file_name)
        
        
Bronze_To_Silver(df)


# COMMAND ----------

import os
Paths = dbutils.fs.ls('/Project/Bronze')
path_list = [item.path for item in Paths]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame
df = spark.createDataFrame([(path,) for path in path_list], schema)
Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)
# Show DataFrame
df.show(truncate=False)
def Landing_To_Bronze(df):
    for row in df.collect():
        file_path = row.path
        print(file_path)
        file_name = os.path.basename(os.path.normpath(file_path))
        print(file_name)

# Call the function
Landing_To_Bronze(df)

# COMMAND ----------

