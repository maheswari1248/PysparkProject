# Databricks notebook source
# MAGIC %md 
# MAGIC
# MAGIC ## This is the Main notebook use to execute the workflow

# COMMAND ----------

# MAGIC %md 
# MAGIC >> execute landing_to_bronze notebook

# COMMAND ----------

# MAGIC %run /Users/maheswari.ramadasu@xyenta.com/Nb_Landing_To_Bronze

# COMMAND ----------

