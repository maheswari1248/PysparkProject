# Databricks notebook source
from datetime import datetime
import os

from pyspark.sql.types import *
from pyspark.sql.functions import *


# Function to process DataFrame
def process_dataframe(df, metadata, folder_name, file_name):
    
    # Convert column names to lowercase and remove spaces
    df = df.toDF(*[col.lower().replace(" ", "") for col in df.columns])
    
    # Check if the columns and their data types match with metadata
    metadata_columns = metadata.select('Columns').collect()
    metadata_Staging = metadata.select('StagingNames').collect()
    for row, staging_name_row in zip(metadata_columns, metadata_Staging):
        source_column = row[0]
        staging_name = staging_name_row[0]
        if source_column and staging_name in df.columns:
            metadata_row = metadata.filter(metadata.Columns).collect()
            if metadata_row:
                metadata_row = metadata_row[0]
                source_datatype = metadata_row.SourceDataType
                Metadata_target_datatype = metadata_row.TargetDataType
                target_data_type = df.select(source_column).dtypes[0][1]
                if target_data_type != Metadata_target_datatype:
                    print(f"Error: Target data type of column '{source_column}' ({Metadata_target_datatype}) does not match the actual data type ({target_data_type})")
                    error_msg = f"Error: Target data type of column '{source_column}' ({Metadata_target_datatype}) does not match the actual data type ({target_data_type})"
                    raise ValueError(error_msg)
            else:
                print(f"Error: Column '{source_column}' not found in metadata.")
              
        
    # Replacing  any rows with missing values
    for col_name in df.columns:
        if df.schema[col_name].dataType == IntegerType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit(0)).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == StringType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("unknown")).otherwise(df[col_name]))
        elif df.schema[col_name].dataType == DateType():
            df = df.withColumn(col_name, when(df[col_name].isNull(), lit("9999-22-9999")).otherwise(df[col_name]))
        
    # Drop duplicate rows
    df = df.dropDuplicates()

    # Check for null values
    null_counts = {col_name: df.filter(df[col_name].isNull()).count() for col_name in df.columns}
    for col_name, count in null_counts.items():
        print(f"Null count in {col_name}: {count}")

    # Check for duplicate rows
    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
    print("Duplicates count:")
    count_duplicates.show()

    # Print schema
    df.printSchema()
    display(df)
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day

    # Define the output path
    output_path = f"dbfs:/Project/Silver/{folder_name}/{year}/{month}/{day}/{year}-{month}-{day}/"
    
    # Write the DataFrame to the output path
    df.write.mode("overwrite").parquet(output_path)
    
    return df

# Function to dynamically rename DataFrame columns
def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# Retrieve paths from Landing area
Paths_landing = dbutils.fs.ls('/Project/Landing')
path_list_landing = [item.path for item in Paths_landing]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame from landing paths
df_landing = spark.createDataFrame([(path,) for path in path_list_landing], schema)



# Process each file in Landing area
for row in df_landing.collect():
    file_path = row.path
    file_name = os.path.basename(file_path).split(".")[0]
    today_date = datetime.now()
    year = today_date.year
    month = today_date.month
    day = today_date.day
    
   
    formatted_path = f"/Project/Bronze/{file_name}/{year}/{month}/{day}/{year}-{month}-{day}"
   
    Paths = dbutils.fs.ls(formatted_path)
    path_list = [item.path for item in Paths]
    schema = StructType([StructField("path", StringType(), True)])
    df = spark.createDataFrame([(path,) for path in path_list], schema)
    display(df)

# Function to convert Bronze to Silver
def Bronze_To_Silver(df):
    for row in df.collect():
        Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)
        file_path = row.path
        file_name = file_path.split("/")[-1].split(".")[0]
        df = spark.read.csv(file_path, header=True, inferSchema=True)
        process_dataframe(df, Metadata, file_name, file_name)
        
# Convert Bronze to Silver
Bronze_To_Silver(df_landing)



# COMMAND ----------

Metadata = spark.read.csv('dbfs:/Project/Metadata/Metadata_Colums.csv', header=True)
display(Metadata)

# COMMAND ----------

from datetime import datetime
dt_str = datetime.now().strftime('%Y/%m/%d/%Y-/%m-/%d')
print(dt_str)

# COMMAND ----------

def rename_columns(df):
    return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# Retrieve paths from Landing area
Paths_landing = dbutils.fs.ls('/Project/Landing')
path_list_landing = [item.path for item in Paths_landing]

# Define schema for DataFrame
schema = StructType([StructField("path", StringType(), True)])

# Create DataFrame from landing paths
df_landing = spark.createDataFrame([(path,) for path in path_list_landing], schema)

filenames = ['Xyenta_Leaves_2022', 'EmployeeLoginDetails']

def datevalidation(filename):
    try:
        df = spark.read.csv(f"dbfs:/Project/Landing/{filename}.csv", header=True, inferSchema=True)
        # display(df)
        
        Metadata = spark.read.csv('dbfs:/FileStore/Metadata_Colums-2.csv', header=True)
        display(Metadata)
        

        ref_filter = Metadata.filter(col('StagingNames') == filename)
        display(ref_filter)
        
        IsDatecompare = ref_filter.filter(col('IsDate')=='Y')
        print("ISCOMPARE")
        display(IsDatecompare)
        
        for row in IsDatecompare.collect():
            date_column = row['Columns']
            format_check = 'dd MMM yyyy'
            print("hello")
            dfs = df.withColumn(
                'bad_record',
                when(col(date_column).isNull(), "False")
                .when(to_date(col(date_column), format_check).isNotNull(), "True")
                .otherwise("False")
            )
            # display(dfs)
            
            bad_records_df = dfs.filter(col('bad_record') == "False")
            good_records_df = dfs.filter(col('bad_record') == "True")

            bad_record_df_count = bad_records_df.count()
            print(bad_record_df_count)
            display(bad_records_df)
            good_records_df_count = good_records_df.count()
            display(good_records_df)

            if bad_record_df_count > 0 :
                print("entered into bad_records...")
                bad_path = f"dbfs:/Project/BadRecords/{filename}-DateMissmatched/{dt_str}/"
                bad_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(bad_path)
                print("written to bad path")
            
            if good_records_df_count > 0:
                print("entered into good_records...")
                good_path = f"dbfs:/Project/Silver/{filename}/{dt_str}/"
                good_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(good_path)
                print("done written to gold path")

        else : 
            print("No date column found..")

    except Exception as e:
        print(f"An error occurred while processing the datevalidation method : {str(e)}")    
filenames = ['Xyenta_Leaves_2022', 'EmployeeLoginDetails']

for filename in filenames:
    try:
        datevalidation(filename)
    except Exception as e:
        print(f"An error occurred while processing filename '{filename}': {str(e)}")



# COMMAND ----------

# from datetime import datetime
# x = datetime.now()
# print(x.strftime("%d %b %Y"))

# data = [("25 Mar 2024" , ), ("aa bb dddd", )]
# cols = ["id"]

# df = spark.createDataFrame(data, cols)
# df.show()
# format_check = "dd MMM yyyy"

# # df2 = df.withColumn("date", to_date(col("id"), format_check)).show()

# df2 = df.withColumn(
#                         'bad_record',
#                         when(col("id").isNull(), "False")
#                         .when(to_date(col("id"), format_check).isNotNull(), "True")
#                         .otherwise("False")
#                     ).show()

# COMMAND ----------

# def rename_columns(df):
#     return df.toDF(*[col.lower().replace(" ", "") for col in df.columns])

# # Retrieve paths from Landing area
# Paths_landing = dbutils.fs.ls('/Project/Landing')
# path_list_landing = [item.path for item in Paths_landing]

# # Define schema for DataFrame
# schema = StructType([StructField("path", StringType(), True)])

# # Create DataFrame from landing paths
# df_landing = spark.createDataFrame([(path,) for path in path_list_landing], schema)



# def datevalidation(path):
#     try:

#         df = spark.read.csv("dbfs:/Project/Landing/Xyenta_Leaves_2022.csv", header=True, inferSchema=True)
#         display(df)
        
#         # Read metadata
#         Metadata = spark.read.csv('dbfs:/FileStore/Metadata_Colums-2.csv', header=True)
        
#         # Filter metadata for relevant columns filename
#         ref_filter = Metadata.filter(col('StagingNames') == filename)
#         # dateColumn_ref = [row['Columns'] for row in ref_filter.select('Columns').filter(col("Columns").contains("Date")).collect()]
#         # print("datecolumn_ref")
#         # print(dateColumn_ref)
        
#         # # Filter DataFrame columns for those containing 'Date'
#         # datecolumns_dfs = [x for x in df.columns if 'Date' in x]
#         # print(datecolumns_dfs)
#         ref_filter = Metadata.filter(col('StagingNames') == filename)
#         display(ref_filter)
        
#         IsDatecompare = ref_filter.filter(col('IsDate')=='Y').select('Columns')
#         print("ISCOMPARE")
#         display(IsDatecompare)
        
#         for row in IsDatecompare.collect():
#             date_column = row['Columns']
#                     format_check = 'dd MMM yyyy'
#                     print("hello")
#                     dfs = df.withColumn(
#                         'bad_record',
#                         when(col(date_column).isNull(), "False")
#                         .when(to_date(col(date_column), format_check).isNotNull(), "True")
#                         .otherwise("False")
#                     )
#                     # display(dfs)
#                 else:
#                     print(f"No date columns found in the {filename}")

#             #dbfs:/Project/BadRecords/
#             bad_records_df = dfs.filter(col('bad_record') == "False")
#             good_records_df = dfs.filter(col('bad_record') == "True")

#             bad_record_df_count = bad_records_df.count()
#             print(bad_record_df_count)
#             display(bad_records_df)
#             good_records_df_count=good_records_df.count()
#             display(good_records_df)
            

#             if bad_record_df_count > 0 :
#                 print("entered into bad_records...")
#                 bad_path = f"dbfs:/Project/BadRecords/{filename}-DateMissmatched/{dt_str}/"
#                 bad_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(bad_path)
#                 print("written to bad path")
            
#             if good_records_df_count > 0:
#                 print("entered into bad_records...")
#                 good_path = f"dbfs:/Project/Silver/{filename}/{dt_str}/"
#                 good_records_df.coalesce(1).write.mode('overwrite').option('Header', True).format('parquet').save(good_path)
#                 print("done written to gold path")

#         else : 
#             print("No date column found..")

#     except Exception as e:
#         print(f"An error occured while proccessing the datevalidation method : {str(e)}")    

