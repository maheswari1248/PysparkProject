# Databricks notebook source
###############################################CSV###########################################################

# COMMAND ----------

#######################################CSV###################################################################

# COMMAND ----------


from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day

df = spark.read.csv('dbfs:/FileStore/EmployeeLoginDetails-8.csv',header=True)
SourceDF= df.select("Designation")

# COMMAND ----------

display(SourceDF)

# COMMAND ----------

dim_df=spark.sql("select * from dev.dimdesignation")
display(dim_df)

# COMMAND ----------

new_records = SourceDF.join(dim_df, SourceDF["designation"] == dim_df["designation"], "left_anti").select(SourceDF["*"])
display(new_records)


# COMMAND ----------

existing_records=SourceDF.join(dim_df, SourceDF["designation"] == dim_df["designation"], "inner").select(dim_df["*"])

existing_records=existing_records.select("designation")
display(existing_records)

# COMMAND ----------

combined=new_records.unionByName(existing_records).distinct()
display(combined)

# COMMAND ----------

combined.write.mode('overwrite').saveAsTable("dev.dimdesignation")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimdesignation

# COMMAND ----------

