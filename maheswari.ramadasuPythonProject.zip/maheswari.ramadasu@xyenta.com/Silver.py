# Databricks notebook source


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, DateType, StringType
from pyspark.sql.functions import col, lower, to_timestamp

# Define the schema
schema = StructType([
    StructField("Employee Name", StringType(), True),
    StructField("PK_EmpID", StringType(), True),
    StructField("Designation", StringType(), True),
    StructField("AttendenceDate", StringType(), True),
    StructField("First In Time", DateType(), True),
    StructField("Last Out Time", DateType(), True)
])

# Read CSV file with specified schema
df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, schema=schema)
df.show()

# Convert "AttendenceDate" column to timestamp type
#df = df.withColumn("AttendenceDate", to_timestamp("AttendenceDate", "MM-dd-yyyy HH:mm:ss"))

# Rename columns to lowercase and remove spaces
# for column in df.columns:
#     df = df.withColumnRenamed(column, column.lower().replace(" ", ""))

# # Iterate over each column and count the null values
# null_counts = {col_name: df.filter(col(col_name).isNull()).count() for col_name in df.columns}

# # Print the null counts for each column
# for col_name, count in null_counts.items():
#     print(f"Null count in {col_name}: {count}")

# # Check for duplicates
# count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
# print("Duplicate rows count:")
# count_duplicates.show()

# # Print DataFrame schema
# print("DataFrame schema:")
# df.printSchema()

# # Show DataFrame
# print("DataFrame content:")
# display(df)


# COMMAND ----------

df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
df.show()
df.schema

# COMMAND ----------



# COMMAND ----------





# COMMAND ----------



# COMMAND ----------


##converting the Cleaning df into the Parqueet file
from datetime import datetime

# Get today's date
today_date = datetime.now()

# Extract year, month, and day from the date
year = today_date.strftime("%Y")
month = today_date.strftime("%m")
day = today_date.strftime("%d")

# Define the path including the year, month, and day folders
output_path = f"dbfs:/Landing/Silver/{year}/{month}/{day}/"

# Write DataFrame to Parquet file
df.write.mode("overwrite").parquet(output_path)


# COMMAND ----------



# COMMAND ----------

display(dbutils.fs.ls("/Landing/Metadata"))

# COMMAND ----------

#Reading the csvs 
#len
employee=spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv",header=True)
len_emp=len(employee.columns)
XyentaHolidays=spark.read.csv("dbfs:/Landing/XyentaHolidays.csv",header=True)
len_holiday=len(XyentaHolidays.columns)
Xyenta_Leaves=spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv",header=True)
len_leaves=len(Xyenta_Leaves.columns)-3
Total=len_emp+len_holiday+len_leaves
#print(Total)

#Reading the MetadataColumns
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()
#print("Number of columns in the 'Columns' column:", column_count)
count=0
if Total==column_count:
    def convert_datatypes(employee,Metadata):
        for row in Metadata.collect():
            global count
            if row['SourceDataType']==row['TargetDataType']:
                  continue
            else:
                df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
                Convert "AttendenceDate" column to timestamp type
                    df = df.withColumn("AttendenceDate", to_timestamp("AttendenceDate", "MM-dd-yyyy HH:mm:ss"))

                    Rename columns to lowercase and remove spaces
                    for column in df.columns:
                        df = df.withColumnRenamed(column, column.lower().replace(" ", ""))

                    # Iterate over each column and count the null values
                    null_counts = {col_name: df.filter(col(col_name).isNull()).count() for col_name in df.columns}

                    # Print the null counts for each column
                    for col_name, count in null_counts.items():
                        print(f"Null count in {col_name}: {count}")

                    # Check for duplicates
                    count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
                    print("Duplicate rows count:")
                    count_duplicates.show()

                
        
else:
    print("Not Equals")

convert_datatypes(employee,Metadata)

# COMMAND ----------

def convert_datatypes(employee,Metadata):
        for row in Metadata.collect():
            for row1 in employee:
                display(employee.columns)
            display(row['Columns'])
convert_datatypes(employee,Metadata)

# COMMAND ----------

df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
df.printSchema()


# COMMAND ----------

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True)
len_emp = len(employee.columns)

XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True)
len_holiday = len(XyentaHolidays.columns)

Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True)
len_leaves = len(Xyenta_Leaves.columns) - 3

Total = len_emp + len_holiday + len_leaves

# Reading the Metadata Columns
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()
print(Total)
print(column_count)

# Function to convert datatypes
def convert_datatypes(employee, Metadata):
    if Total == column_count:
        for row in Metadata.collect():
            if row['SourceDataType'] == row['TargetDataType']:
                continue
            elif row['SourceDataType'] == row['TargetDataType']:
                df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
                # Convert "AttendenceDate" column to timestamp type
                df = df.withColumn("AttendenceDate", to_timestamp("AttendenceDate", "MM-dd-yyyy HH:mm:ss"))

                # Rename columns to lowercase and remove spaces
                for column in df.columns:
                    df = df.withColumnRenamed(column, column.lower().replace(" ", ""))

                # Iterate over each column and count the null values
                null_counts = {col_name: df.filter(col(col_name).isNull()).count() for col_name in df.columns}

                # Print the null counts for each column
                for col_name, count in null_counts.items():
                    print(f"Null count in {col_name}: {count}")

                # Check for duplicates
                count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
                print("Duplicate rows count:")
                count_duplicates.show()
    else:
        print("Total number of columns does not match the number of columns in Metadata.")

# Calling the function
convert_datatypes(employee, Metadata)


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, DateType, StringType
from pyspark.sql.functions import col, lower, to_timestamp

# Reading the CSVs and calculating lengths
employee = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True)
len_emp = len(employee.columns)

XyentaHolidays = spark.read.csv("dbfs:/Landing/XyentaHolidays.csv", header=True)
len_holiday = len(XyentaHolidays.columns)

Xyenta_Leaves = spark.read.csv("dbfs:/Landing/Xyenta_Leaves_2022.csv", header=True)
len_leaves = len(Xyenta_Leaves.columns) - 3

Total = len_emp + len_holiday + len_leaves

# Reading the Metadata Columns
Metadata = spark.read.csv('dbfs:/Landing/Metadata/Metadata_Colums.csv', header=True)
column_count = Metadata.select('Columns').count()
print(Total)
print(column_count)

# Function to convert datatypes
def convert_datatypes(employee, Metadata):
    if Total == column_count:
        for row in Metadata.collect():
            if row['SourceDataType'] == row['TargetDataType']:
                continue
            elif row['SourceDataType'] != row['TargetDataType']:
                df = spark.read.csv("dbfs:/Landing/EmployeeLoginDetails.csv", header=True, inferSchema=True)
                # Convert "AttendenceDate" column to timestamp type
                df = df.withColumn("AttendenceDate", to_timestamp("AttendenceDate", "MM-dd-yyyy HH:mm:ss"))

                # Rename columns to lowercase and remove spaces
                for column in df.columns:
                    df = df.withColumnRenamed(column, column.lower().replace(" ", ""))

                # Iterate over each column and count the null values
                null_counts = {col_name: df.filter(col(col_name).isNull()).count() for col_name in df.columns}

                # Print the null counts for each column
                for col_name, count in null_counts.items():
                    

                # Check for duplicates
                  count_duplicates = df.groupBy(df.columns).count().filter("count > 1")
        print(f"Null count in {col_name}: {count}")        
        print("Duplicate rows count:") 
        count_duplicates.show()    
    else:
        print("Total number of columns does not match the number of columns in Metadata.")

# Calling the function
convert_datatypes(employee, Metadata)


# COMMAND ----------

 