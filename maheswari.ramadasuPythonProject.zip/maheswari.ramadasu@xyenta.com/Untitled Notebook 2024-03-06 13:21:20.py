# Databricks notebook source
data=[(1,'mahe'),(2,'Ammu')]
#Creating the schema
schema=['id','name']
#Creating A DataFrame
df=spark.createDataFrame(data,schema)
#It Tells the What Type of DataType is 
df.printSchema()
#displays the output in table format
display(df)
#displays the output
df.show()

# COMMAND ----------

from pyspark.sql.types import *

data=[(1,'mahe'),(2,'Ammu')]
#Creating the schema for converting datatype
schema=StructType([StructField(name='id',dataType=IntegerType()),StructField(name='name',dataType=StringType())])
#Creating A DataFrame
df=spark.createDataFrame(data,schema)
df.printSchema()


# COMMAND ----------

#Reading csv
df=spark.read.csv("dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/loandata.csv",header=True)
display(df)

# COMMAND ----------

data=[(1,'Maheswari')]
schema=['id','Name']
df=spark.createDataFrame(data,schema)
display(df)
#Converting the dataframe into csv
#df.write.csv(path="dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/mahe.csv",header=True)
#reading the csv 
print("Reading the CSV")
display(spark.read.csv(path="dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/mahe.csv",header=True))
print("successfully ")

# COMMAND ----------

# Read CSV into DataFrame
df = spark.read.csv("dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/loandata.csv", header=True)
# Write DataFrame to Parquet file
output_path = "dbfs:/FileStore/parquet_output/loan.parquet"
#df.write.parquet(output_path)
# Read Parquet file into DataFrame
df = spark.read.parquet("dbfs:/FileStore/parquet_output/loandata.parquet")
# Show the DataFrame
display(df)
#To know the count we use count()
display(df.count())
print("successful")


# COMMAND ----------

#show()
#1.normally displaying the data output:mmmmmmmmmmmmmmmmm...
data=[(1,'mmmmmmmmmmmmmmmmmmmmmmmmsaaaaaaaaaaasss')]
schema=['id','name']
df=spark.createDataFrame(data,schema)
df.show()

#To display the whole name then
df.show(truncate=False)

#To get first 8 letters then
df.show(truncate=8)

# COMMAND ----------

#######-------------------WITHCOLUMN-------------------------------------------------##########
from pyspark.sql.types import *
df1=spark.read.csv("dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/loandata.csv", header=True)
print("csv")
df1.printSchema()
df = spark.read.parquet("dbfs:/FileStore/parquet_output/loandata.parquet")
print("parquet")
df.printSchema()

# COMMAND ----------

