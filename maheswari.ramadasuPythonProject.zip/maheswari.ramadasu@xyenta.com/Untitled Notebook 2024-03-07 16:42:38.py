# Databricks notebook source
import pyspark.sql
df = spark.read.parquet("dbfs:/Landing/Silver/2024/03/07/part-00000-tid-7522442259921714896-9e9e8066-93b0-4f0c-ad38-b3f38874e1c2-248-1-c000.snappy.parquet")
df.show()