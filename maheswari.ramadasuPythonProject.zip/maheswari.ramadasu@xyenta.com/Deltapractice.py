# Databricks notebook source
display(dbutils.fs.ls("/Landing/Silver"))

# COMMAND ----------

from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from pyspark.sql.functions import monotonically_increasing_id

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Create Delta Table") \
    .getOrCreate()

# Create a DataFrame with sample data
data = [None,None]
schema=[("id","ManagerNo","ManagerName")]
df = spark.createDataFrame(data, schema)

# Add an auto-increment column "id"
df = df.withColumn("id", monotonically_increasing_id())

# Specify the Delta table path
delta_table_path = "dbfs:/FileStore/Manager/emp"

# Write the DataFrame to the specified path in Delta format
df.write.format("delta").save(delta_table_path)

# Convert the directory to a Delta table
delta_table = DeltaTable.forPath(spark, delta_table_path)

# Print the schema of the Delta table
delta_table.toDF().printSchema()


# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql import SparkSession

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Read Delta Table") \
    .getOrCreate()

# Path to the Delta table
delta_table_path = "dbfs:/FileStore/delta-table-path/emp"

# Load the Delta table as a DataFrame
df = spark.read.format("delta").load(delta_table_path)

# Show the contents of the DataFrame
df.show()



# COMMAND ----------

