# Databricks notebook source
# MAGIC %sql
# MAGIC create table Fact(
# MAGIC   Sno LONG GENERATED ALWAYS AS IDENTITY ,   
# MAGIC   FK_EmployeeKey long,
# MAGIC   FK_Designationkey long,
# MAGIC   ManagerNo string,
# MAGIC   FirstInTime timestamp,
# MAGIC   LastOutTime timestamp
# MAGIC )

# COMMAND ----------

# MAGIC %sql 
# MAGIC drop  table  if exists UspFact

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimdesignation

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimemployee

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimdesignation

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimmanager

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day

# Generate output paths
Paths = f"dbfs:/Project/Silver/EmployeeLoginDetails/{year}/{month}/{day}/{year}-{month}-{day}/"
display(Paths)

SourceDF = spark.read.parquet(Paths)

# # SourceDF=spark.read.csv("dbfs:/FileStore/EmployeeLoginDetails-4.csv",header=True,inferSchema=True)
first = SourceDF.select('firstintime')
# display(firstintime)
last = SourceDF.select('lastouttime')
display(last)
Pk_EmployeeTypeKey=spark.sql("select Pk_EmployeeTypeKey from dev.dimemployee ")
# display(Pk_EmployeeTypeKey)
Pk_DesignationKey=spark.sql("select Pk_DesignationKey from dev.dimdesignation")
# display(Pk_DesignationKey)
ManagerNo=spark.sql("select managerno from dev.dimmanager")
# display(ManagerNo)


# COMMAND ----------


joindf = FactUserActivity.join(SourceDF, FactUserActivity['FirstInTime'] == SourceDF['FirstInTime'], "left_outer")
joindf.show()



# COMMAND ----------

SourceDF = SourceDF.select('firstintime', 'lastouttime').distinct()
SourceDF.printschema()

# COMMAND ----------

FactUserActivity=spark.sql("select * from UspFact")
FactUserActivity.show()

# COMMAND ----------

# from pyspark.sql.types import *

# # Assuming these are your DataFrame schemas
# employee_type_keys = spark.sql("select * from dev.dimemployee")
# designation_keys = spark.sql("select * from dev.dimdesignation")
# manager_nos = spark.sql("select * from dev.dimmanager")
# FactUserActivity = spark.sql("select * from UspFact")

# # Display the contents of FactUserActivity DataFrame
# FactUserActivity.show()

# # Perform the left join and select the desired columns
# joindf = employee_type_keys.join(
#     FactUserActivity,
#     FactUserActivity.FK_EmployeeKey == employee_type_keys.Pk_EmployeeTypeKey,
#     "left"
# ).select(
#     employee_type_keys.Pk_EmployeeTypeKey.alias("Fk_EmployeeTypeKey")
# )

# # Display the resulting DataFrame
# display(joindf)
# display(manager_nos['managerno'])

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select * from dev.dimmanager
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uspfact

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimdesignation

# COMMAND ----------

# Perform the join between employee_type_keys and FactUserActivity
join_df = employee_type_keys.join(
    FactUserActivity,
    FactUserActivity.FK_EmployeeKey == employee_type_keys.Pk_EmployeeTypeKey,
    "left_anti"
).select
(
   FactUserActivity['FK_EmployeeKey'] 
)





# Display the resulting dataframe
display(join_df)


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, LongType, IntegerType, StringType, TimestampType

# Extract values from SQL queries
employee_type_keys = spark.sql("select Pk_EmployeeTypeKey from dev.dimemployee").collect()
designation_keys = spark.sql("select Pk_DesignationKey from dev.dimdesignation").collect()

# Extract values from collected data
employee_type_keys = [row.Pk_EmployeeTypeKey for row in employee_type_keys]
designation_keys = [row.Pk_DesignationKey for row in designation_keys]

# Select relevant columns from SourceDF and distinct
SourceDF = SourceDF.select('firstintime', 'lastouttime').distinct()
display(SourceDF)
display(designation_keys)


# # Extract values from SourceDF
# firstintime = [row.firstintime for row in SourceDF.collect()]
# lastouttime = [row.lastouttime for row in SourceDF.collect()]

# # Create DataFrame with extracted values and SourceDF columns
# data = [(None, emp_type_key, desig_key, firstintime_val, lastouttime_val) 
#         for emp_type_key, desig_key, firstintime_val, lastouttime_val in zip(employee_type_keys, designation_keys, firstintime, lastouttime)]

# # Define the schema for the DataFrame
# schema = StructType([
#     StructField("Sno", LongType(), nullable=True),
#     StructField("FK_EmployeeKey", IntegerType(), nullable=True),
#     StructField("FK_DesignationKey", IntegerType(), nullable=True),
#     StructField("FirstInTimeOut", TimestampType(), nullable=True),
#     StructField("LastOut", TimestampType(), nullable=True)
# ])

# # Create DataFrame with specified schema
# values_df = spark.createDataFrame(data, schema)

# display(values_df)


# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from datetime import *
today_date = datetime.now()
year = today_date.year
month = today_date.month
day = today_date.day
dim_employee=spark.sql("select * from dev.dimemployee")
dim_manager=spark.sql("select * from dev.dimmanager")
dim_designation=spark.sql("select * from dev.dimdesignation")
# Generate output paths
Paths = f"dbfs:/Project/Silver/EmployeeLoginDetails/{year}/{month}/{day}/{year}-{month}-{day}/"
display(Paths)

SourceDF = spark.read.parquet(Paths)
first = SourceDF.select('firstintime')
last = SourceDF.select('lastouttime')

# COMMAND ----------

SourceDF.columns

# COMMAND ----------

