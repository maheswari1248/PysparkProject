# Databricks notebook source
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder \
    .appName("Write and Read Parquet") \
    .getOrCreate()

# Create DataFrame
data = [(1, 'mahe'), (2, 'Ammu')]
schema = ['id', 'name']
df = spark.createDataFrame(data=data, schema=schema)

# Show DataFrame
print("Original DataFrame:")
df.show()

# Write DataFrame to Parquet file
output_path = '/FileStore/parquetoutput.parquet'
df.write.parquet(output_path)'''

# Read Parquet file into a new DataFrame
print("Reading from Parquet file:")
df1 = spark.read.parquet(output_path)
df1.show()




# COMMAND ----------

df1 = spark.read.format("csv").option("header", "true").load("dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com/loandata.csv")
df1.show(20)


# COMMAND ----------

