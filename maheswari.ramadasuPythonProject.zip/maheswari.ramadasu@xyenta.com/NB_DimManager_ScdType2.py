# Databricks notebook source
from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F

# Read the parquet file and select the required columns
stg_df = spark.read.parquet("dbfs:/Project/Silver/Xyenta_Leaves_2022/2024/3/18/2024-3-18/part-00000-tid-1286492193640871202-74e5d865-a50a-40c0-b076-98082b43a3fd-288-1-c000.snappy.parquet")
stg_df = SourceDF.select("managerno", F.col('managername').alias('Manager Name')).distinct() 
# Filter out rows where both "managerno" and "managername" are unknown
dim_df = spark.sql("SELECT * FROM dev.DimManager")
dim_df.show()
stg_df.show()

# COMMAND ----------

update_df = stg_df.join(
    dim_df,
    (stg_df["managerno"] == dim_df["ManagerNo"]),
    "inner"
) \
    .filter((stg_df["Manager Name"] != F.col("ManagerName")) ) \
    .filter(F.col("endDate").isNull()) \
    .select(
        dim_df["*"]
       
    ) \
    .withColumn("endDate", F.current_date()) \
    .withColumn("ActiveIndicator", F.lit("N"))

update_df=update_df.select("ManagerNo","ManagerName","ActiveIndicator","startDate","endDate")
update_df.show()

# COMMAND ----------

stg_df.show()

# COMMAND ----------

from pyspark.sql.functions import lit, current_date

# Perform the left anti-join operation and select the required columns
comparison_df = stg_df.join(
    dim_df,
    stg_df["managerno"] == dim_df["ManagerNo"],
    'left_anti'
).select(
    stg_df["managerno"].alias("ManagerNo"),  # Rename the column to match the selected column
    stg_df["Manager Name"].alias("ManagerName"),  # Rename the column to match the selected column
    lit('Y').alias("ActiveIndicator"),
    current_date().alias('startDate'),
    lit('9999-12-31').alias('endDate')
)

# Show the DataFrame
comparison_df.show()


# COMMAND ----------

stg_df.show()

# COMMAND ----------

updated_records_df = stg_df.join(
    update_df.select("managerno"),
    on=stg_df["managerno"] == update_df["ManagerNo"],
    how="inner"
).select(
    stg_df["managerno"].alias("ManagerNo"),
    stg_df["Manager Name"].alias("ManagerName"),
    F.lit('Y').alias("ActiveIndicator"),
    F.current_date().alias("startDate"),
    F.lit("9999-12-31").alias("endDate")
)
updated_records_df.show()

# COMMAND ----------

updated_records_df=updated_records_df.withColumn("endDate", to_timestamp("endDate"))
updated_records_df.printSchema()
comparison_df = comparison_df.withColumn("endDate", to_timestamp("endDate"))

# COMMAND ----------

merge_up = update_df.unionByName(updated_records_df)

# COMMAND ----------

merge_up.show()

# COMMAND ----------

Final = merge_up.unionByName(comparison_df)

# COMMAND ----------

Final.show()

# COMMAND ----------

Final.write.mode('append').saveAsTable("dev.DimManager")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.DimManager

# COMMAND ----------

