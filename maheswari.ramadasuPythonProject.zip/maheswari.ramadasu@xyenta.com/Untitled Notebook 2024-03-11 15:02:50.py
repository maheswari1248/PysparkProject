# Databricks notebook source
s="dbfs:/Landing/Silver/Employee/2024/3/11/9/26/22/part-00000-tid-1216655393273996675-e59d528b-c326-408d-b8b9-fad95a80384d-20-1-c000.snappy.parquet"
o=spark.read.parquet(s)
display(o)


# COMMAND ----------

