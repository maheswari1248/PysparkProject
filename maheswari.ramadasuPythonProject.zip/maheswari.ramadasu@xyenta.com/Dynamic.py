# Databricks notebook source
# MAGIC %sql
# MAGIC create schema if not exists dev

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dev.TControlSCD1 (
# MAGIC   id int,
# MAGIC   LoadType string,
# MAGIC   SourceTableName string,
# MAGIC   SourceColumnNames string,
# MAGIC   AliasColumnNames string,
# MAGIC   IsAutoKey string,
# MAGIC   IsLogicColumn string,
# MAGIC   TargetTableName string,
# MAGIC   TargetColumnNames string,
# MAGIC   IsScd string,
# MAGIC   AdditionalColumns string
# MAGIC );

# COMMAND ----------

# %sql
# -- drop table if exists dev.tcontrolscd

# COMMAND ----------

s=dbutils.fs.ls('/Project/Silver/')
display(s)

# COMMAND ----------


control_df=spark.sql("select * from dev.TControlSCD1 ")
control_df.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO dev.tcontrolscd1 values
# MAGIC (
# MAGIC   1,'SCD1','','','','Y','',''
# MAGIC )
# MAGIC -- (1,"SCD2",""," ",'','Y','','dev.dimemployee','dbfs:/Project/DeltaTables/dev.dimemployee/','Pk_EmployeeType',''),
# MAGIC -- (2,'SCD2',"EmployeeLoginDetails","pk_empid",'','Y','dev.dimemployee',"dbfs:/Project/DeltaTables/dev.dimemployee/",'EmployeeNo',''),
# MAGIC -- (3,'SCD2',"EmployeeLoginDetails",'employeename ','','','dev.dimemployee',"dbfs:/Project/DeltaTables/dev.dimemployee/","EmployeeName",'Y'),
# MAGIC -- (4,'SCD2',"EmployeeLoginDetails",'','','','dev.dimemployee',"dbfs:/Project/DeltaTables/dev.dimemployee/",' ActiveIndicator',''),
# MAGIC -- (5,'SCD2',"EmployeeLoginDetails",'','','','dev.dimemployee',"dbfs:/Project/DeltaTables/dev.dimemployee/",' startDate',''),
# MAGIC -- (6,'SCD2',"EmployeeLoginDetails",'','','','dev.dimemployee',"dbfs:/Project/DeltaTables/dev.dimemployee/",' endDate','')
# MAGIC

# COMMAND ----------

control_df=spark.sql("select * from dev.tcontrolscd")
control_df.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC select  * from dev.tcontrolscd

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import *
tgt_table=control_df.filter(col('TargetTableName')=='dev.dimholiday')
tgt_cols=tgt_table.filter(col('IsAutoKey')!='Y').select('TargetColumnNames').collect()

# COMMAND ----------

display(tgt_table)
display(tgt_cols)

# COMMAND ----------

tgt_cols_list=[row['TargetColumnNames'] for row in tgt_cols]


# COMMAND ----------



# COMMAND ----------

# srctable=[row['SourceTableName'] for row in tgt_table.filter(col('SourceTableName')!='').select('SourceTableName').distinct().collect()]
# for row in srctable:
#     print(row)

tgt_table=control_df.filter(col('TargetTableName')=='dev.dimemployee')
srctable = tgt_table.filter(col('SourceTableName')!='').select('SourceTableName').distinct().collect()[0][0]
print(srctable)

# COMMAND ----------

tgt_table=control_df.filter(col('TargetTableName')=='dev.dimemployee')
tgt_table_name=tgt_table.select('TargetTableName').distinct().collect()[0][0]

# COMMAND ----------

print(tgt_table_name)

# COMMAND ----------

TargetDF=spark.sql("select * from "+tgt_table_name)
TargetDF.show()

# COMMAND ----------

#scd columns

tgt_table = control_df.filter(col('TargetTableName') == 'dev.dimemployee')
#display(tgt_table)

scdcolumns = tgt_table.filter(col('IsScd') == 'Y')
scdcolumns.show(truncate=False)


# COMMAND ----------

# # Assuming `scd_cols` is a list containing the names of the columns

# # Create a comma-separated string of the column names
# scd_list = scdcolumns.selectExpr("concat('', concat_ws(' AND ', collect_list(scd_cols))) as scd_cols")

# # Display the scd_list
# scd_list.show(truncate=False)


# COMMAND ----------


# # s=dbutils.fs.ls("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/18/2024-3-18")
# display(s)
# f=spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/18/2024-3-18")

# COMMAND ----------



# COMMAND ----------

control_df = spark.sql("select * from dev.tcontrolscd")
control_df.show()



# COMMAND ----------

from datetime import datetime
from delta.tables import DeltaTable
from pyspark.sql.functions import col

# Get current timestamp
today_date = datetime.now()

# Extract date components
year = today_date.year
month = today_date.month
day = today_date.day

# Generate output paths
Paths = [
    f"dbfs:/Project/Silver/EmployeeLoginDetails/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/Xyenta_Leaves_2022/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/XyentaHolidays/{year}/{month}/{day}/{year}-{month}-{day}/"
]
DeltaTablesPath = "dbfs:/Project/DeltaTables/"  # Define DeltaTables path
control_df = spark.sql("select * from dev.tcontrolscd")

def HrAnalytics(Paths, DeltaTablesPath, control_df):
    # List Delta tables in DeltaTablesPath directory
    delta_tables = [item.name for item in dbutils.fs.ls(DeltaTablesPath) if item.isDir()]
    for delta_table, path in zip(delta_tables, Paths):
        delta_table_path = f"{DeltaTablesPath}/{delta_table}"
        # Display Delta Table
        # display(f"Delta Table Path: {delta_table_path}")
        targetTable = DeltaTable.forPath(spark, delta_table_path)
        Target_Tablename = delta_table_path.split('/')[-2]
        targetDF=targetTable.toDF()
        # Display data from path
        # display(f"Reading data from path: {path}")
        # display(f"Target table name: {Target_Tablename}")
        sourceDF = spark.read.parquet(path)
        # display(sourceDF)
        Source_table_name = path.split("/")[-6]  # Extract the second-to-last element after splitting by "/"
        # print(Source_table_name)
        # display(f"Source table name: {Source_table_name}")
        #controldf
        # display(control_df_tgt_table)
        # Fetch the value of SourceTableName from control_df
        control_df_src_table = control_df.filter(col('SourceTableName')!='').select('SourceTableName').distinct().collect()[0][0]
        # print(srctable)
        control_df_tgt_table=control_df.filter(col('TargetTablePath')!='').select('TargetTablePath').distinct().collect()[0][0]
        # print('control_df_tgt_table',control_df_tgt_table)
        # print(control_df_src_table)
        # print('delta', delta_table_path)
        #Compare the value with Source_table_name
        # if control_df_src_table == Source_table_name:
        tgt_table = control_df.filter(col('TargetTableName') == Target_Tablename)
        tgt_table.show()

        tgt_cols = [row['TargetColumnNames'] for row in tgt_table.filter(col('IsAutoKey') != 'Y').select('TargetColumnNames').collect()]
        print('tgt_cols')
        print(tgt_cols)

        print('src_cols')
        # src_col = [row['SourceColumnNames'].strip() for row in tgt_table.filter(col('SourceColumnNames') != '').select('SourceColumnNames').collect()]
        src_col = [row['SourceColumnNames'].strip() for row in tgt_table.filter(col('SourceColumnNames') != '').select('SourceColumnNames').collect() if row['SourceColumnNames'].strip()]
   
        print(src_col)
        sourceDf_selected = sourceDF.select(*src_col).distinct()

        # Show the selected DataFrame
        
        display(sourceDf_selected)

        pk_keys = tgt_table.filter(col('IsLogicColumn') == 'Y')
        pk_keys_src = pk_keys.select("SourceColumnNames")
        pk_keys_tgt = pk_keys.select("TargetColumnNames")

        display(pk_keys_src)
        display(pk_keys_tgt)
        joinDf = sourceDF.join(targetDF,sourceDF[pk_keys_src] == targetDF[pk_keys_tgt] , "left_anti")
        joinDf.show()



        # join_condition = [sourceDF[col_name] == targetDF[col_name] for col_name in pk_keys_src_cols]
        # joinDf = sourceDF.join(targetDF,sourceDF[pk_keys_src] == targetDF[pk_keys_tgt] , "left_anti")
        # joinDf.show()
    # .select(
    #     SourceDF["pk_empid"].alias("Source_EmployeeNo"),  
    #     SourceDF["employeename"].alias("Source_EmployeeName"), 
    #     targetDF["EmployeeNo"].alias("Target_EmployeeNo") ,
    #     targetDF["EmployeeName"].alias("Target_EmployeeName") ,
    #     lit("Y").alias("ActiveIndicator"),  
    #     lit("2024-10-21").cast("timestamp").alias("startDate"),  
    #     lit(None).cast("timestamp").alias("endDate")
    # )
              
    
# Call the function with Paths, DeltaTablesPath, and control_df
HrAnalytics(Paths, DeltaTablesPath, control_df)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.tcontrolscd

# COMMAND ----------

from datetime import datetime
from delta.tables import DeltaTable
from pyspark.sql.functions import col

# Get current timestamp
today_date = datetime.now()

# Extract date components
year = today_date.year
month = today_date.month
day = today_date.day

# Generate output paths
Paths = [
    f"dbfs:/Project/Silver/EmployeeLoginDetails/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/Xyenta_Leaves_2022/{year}/{month}/{day}/{year}-{month}-{day}/",
    f"dbfs:/Project/Silver/XyentaHolidays/{year}/{month}/{day}/{year}-{month}-{day}/"
]
DeltaTablesPath = "dbfs:/Project/DeltaTables"  # Define DeltaTables path
control_df = spark.sql("select * from dev.tcontrolscd")

def HrAnalytics(Paths, DeltaTablesPath, control_df):
    for delta_table, path in zip(delta_tables, Paths):
        delta_table_path = f"{DeltaTablesPath}/{delta_table}"
        targetTable = DeltaTable.forPath(spark, delta_table_path)
        Target_Tablename = delta_table_path.split('/')[-2]
        
        sourceDF = spark.read.parquet(path)
        Source_table_name = path.split("/")[-6]
        
        control_df_src_table = control_df.filter(col('SourceTableName')!='').select('SourceTableName').distinct().collect()[0][0]
        control_df_tgt_table = control_df.filter(col('TargetTablePath')!='').select('TargetTablePath').distinct().collect()[0][0]
        
        tgt_table = control_df.filter(col('TargetTableName')==Target_Tablename)
        tgt_cols = tgt_table.filter(col('IsAutoKey') != 'Y').select('TargetColumnNames').collect()
        for row in tgt_cols:
            print(row['TargetColumnNames']) 
        
        src_cols = tgt_table.filter(col('SourceColumnNames') != '').select('SourceColumnNames').collect()
        for row in src_cols:
            print(row['SourceColumnNames'])
        
        pk_keys = tgt_table.filter(col('IsLogicColumn') == 'Y')
        pk_keys_src = pk_keys.select("SourceColumnNames")
        pk_keys_tgt = pk_keys.select("TargetColumnNames")
        
        targetDF = targetTable.toDF()  # Fixed the case here
        display(targetDF)
        
        joinDf = sourceDF.join(targetDF, (targetDF[pk_keys_tgt] == sourceDF[pk_keys_src]), "left_outer")
        joinDf.show()
# Call the function with Paths, DeltaTablesPath, and control_df
HrAnalytics(Paths, DeltaTablesPath, control_df)


# COMMAND ----------

display(dbutils.fs.ls("/Project/DeltaTables"))
targetTable=DeltaTable.forPath(spark,"dbfs:/Project/DeltaTables/DimEmployee")
targetDF=targetTable.toDF()

# COMMAND ----------

