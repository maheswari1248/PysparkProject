# Databricks notebook source
def tables_to_file(tablename):
    df=spark.sql("select * from "+tablename)
    df.coalesce(1)