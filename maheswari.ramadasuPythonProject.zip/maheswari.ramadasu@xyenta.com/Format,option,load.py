# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# COMMAND ----------

spark=spark.read.format('csv').option('header','True').option('inferSchema','True').load('dbfs:/Landing/EmployeeLoginDetails.csv').printSchema()

# COMMAND ----------

