# Databricks notebook source



# Read the Parquet file
s = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")


# Write the DataFrame as a Delta table in the dev schema
s.write.format("delta").saveAsTable("dev.EmployeeLoginDetails")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimemployee;
# MAGIC --insert into dev.dimemployee(EmployeeNo,EmployeeName,ActiveIndicator,startDate,endDate) values(1,'mahe','Y','2024-10-10','2024-10-11')
# MAGIC --select * from dev.dimemployee;

# COMMAND ----------

# Read the Delta table into a DataFrame
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")

# Read the Parquet file into a DataFrame and select specific columns
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
df_employee = df_employee.select('pk_empid', 'employeename')

# Show the DataFrames
df_dimemployee.show()
df_employee.show()


# COMMAND ----------

from pyspark.sql.functions import lit

df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
df_employee = df_employee.select('pk_empid', 'employeename')
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")

MergeDf = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"]) & (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        df_employee["pk_empid"].alias("EmployeeNo"),  
        df_employee["employeename"].alias("EmployeeName"),  
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )

# Show the resulting DataFrame
MergeDf.show()

# Save the DataFrame as a Delta table
MergeDf.write.format("delta").mode("overwrite").saveAsTable("dev.dimemployee")


# COMMAND ----------

spark.sql("select * from dev.dimemployee").show()



# COMMAND ----------

from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F

# Assuming joinDf and df_dimemployee are defined
# Filter condition
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
df_employee = df_employee.select('pk_empid', 'employeename')
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")
joinDf = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"])& (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        df_employee["pk_empid"].alias("Source_EmployeeNo"),  
        df_employee["employeename"].alias("Source_EmployeeName"), 
        df_dimemployee["EmployeeNo"].alias("Target_EmployeeNo") ,
        df_dimemployee["EmployeeName"].alias("Target_EmployeeName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )

#joinDf.show()
filterDf = joinDf.filter(xxhash64(joinDf.Source_EmployeeNo, joinDf.Source_EmployeeName) != xxhash64(joinDf.Target_EmployeeNo, joinDf.Target_EmployeeName))

# Display filterDf
#filterDf.show()

mergeDf = filterDf.withColumn("MERGEKEY", concat(filterDf.Source_EmployeeNo, filterDf.Source_EmployeeName))

# Display mergeDf
#mergeDf.show()
#   Only The updated Value will come
dummyDf = filterDf.filter("Target_EmployeeNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
#dummyDf.show()

scdDf = mergeDf.union(dummyDf)

# Show scdDf
display(scdDf)





# Define the merge condition
merge_condition = """
    target.EmployeeNo = source.Source_EmployeeNo AND
    target.EmployeeName = source.Source_EmployeeName AND
    target.ActiveIndicator='y'
"""

# Perform the merge operation


mergeStatement = df_dimemployee.alias("target").merge(
    source=scdDf.alias("source"),
    condition=merge_condition
).whenMatchedUpdate(
    set={"ActiveIndicator": lit("N"), "endDate": current_date()}
).whenNotMatchedInsert(
    values={
        "EmployeeNo": F.col("source.Source_EmployeeNo"),
        "EmployeeName": F.col("source.Source_EmployeeName"),
        "ActiveIndicator": lit("Y"),
        "startDate": lit("2024-10-21"),
        "endDate": lit(None).cast("timestamp")
    }
)



# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dev.dimemployee

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists dev.dimemployee

# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql import functions as F
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
stg_df = df_employee.select('pk_empid', 'employeename')
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")
display(df_dimemployee)
#inserting the new records

newrecords = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"]) & (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_anti") 
display(stg_df)
#update
update_df = stg_df.join(
    df_dimemployee,
    (stg_df["pk_empid"] == df_dimemployee["EmployeeNo"],
    "inner"
) \
    .filter((stg_df["pk_empid"] != F.col("EmployeeNo")) & (stg_df["employeename"] != F.col("EmployeeName"))) \
    .filter(F.col("dim.endDate").isNull()) \
    .select(
        "EmployeeNo", 
        "EmployeeName", 
        "ActiveIndicator", 
        "startDate", 
        "endDate"
    ) \
    .withColumn("endDate", F.current_date()) \
    .withColumn("ActiveIndicator", F.lit("N"))
display(update_df)

#updated records
update_records=stg_df.join(update_df,df_dimemployee["EmployeeNo"] == df_employee["pk_empid"],"inner")
merge_up=update_df.unionByName(update_records)
display(merge_up)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import *

# Import Libraries

# Assuming joinDf and df_dimemployee are defined
# Filter condition
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
df_employee = df_employee.select('pk_empid', 'employeename')
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")
joinDf = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"])& (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        df_employee["pk_empid"].alias("Source_EmployeeNo"),  
        df_employee["employeename"].alias("Source_EmployeeName"), 
        df_dimemployee["EmployeeNo"].alias("Target_EmployeeNo") ,
        df_dimemployee["EmployeeName"].alias("Target_EmployeeName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )
filterDf = joinDf.filter(xxhash64(joinDf.EmployeeNo, joinDf.EmployeeName) != xxhash64(joinDf.EmployeeNo, joinDf.EmployeeName))

# Display filterDf
filterDf.show()

# MergeDf with MERGEKEY
mergeDf = filterDf.withColumn("MERGEKEY", concat(filterDf.EmployeeNo, filterDf.EmployeeName))

# Display mergeDf
mergeDf.show()

# Create dummyDf with MERGEKEY as None
dummyDf = filterDf.filter("EmployeeNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
dummyDf.show()

# Union mergeDf and dummyDf to create scdDf
scdDf = mergeDf.union(dummyDf)

# Show scdDf
scdDf.show()

# Merge statement


# Execute the merge statement and display results
mergeStatement.show()


# COMMAND ----------

from pyspark.sql.functions import lit, current_date
from pyspark.sql import functions as F

# Read the employee login details data
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")

# Select relevant columns from the employee login details data
stg_df = df_employee.select('pk_empid', 'employeename')

# Read the dimension employee data as a Delta table
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")

# Display the existing dimension employee data
display(df_dimemployee)

# Insert new records
newrecords = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"]) & (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_anti") 
    
display(newrecords)
# Update existing records
update_df = stg_df.join(
    df_dimemployee.alias("dim"),
    (stg_df["pk_empid"] == F.col("dim.EmployeeNo")),
    "inner"
) \
    .filter((stg_df["pk_empid"] != F.col("dim.EmployeeNo")) & (stg_df["employeename"] != F.col("dim.EmployeeName"))) \
    .filter(F.col("dim.endDate").isNull()) \
    .select(
        "dim.EmployeeNo", 
        "dim.EmployeeName", 
        "dim.ActiveIndicator", 
        "dim.startDate", 
        "dim.endDate"
    ) \
    .withColumn("endDate", F.current_date()) \
    .withColumn("ActiveIndicator", F.lit("N"))

#display(update_df)
# Update Records
update_records = stg_df.join(update_df, stg_df["pk_empid"] == F.col("dim.EmployeeNo"), "inner") 
#display(update_records)

#Merging the Records
#merge_up = update_df.unionByName(update_records)
#display(merge_up)


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from dev.dimemployee

# COMMAND ----------

from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F

# Assuming joinDf and df_dimemployee are defined
# Filter condition
df_employee = spark.read.parquet("dbfs:/Project/Silver/EmployeeLoginDetails/2024/3/15/2024-3-15/part-00000-tid-8044766437758260075-525fe15d-3473-4eed-b90f-33b69e8a8d59-1140-1-c000.snappy.parquet")
df_employee = df_employee.select('pk_empid', 'employeename')
df_dimemployee = spark.read.format("delta").table("dev.dimemployee")
joinDf = df_employee.join(df_dimemployee, (df_dimemployee["EmployeeNo"] == df_employee["pk_empid"])& (df_dimemployee["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        df_employee["pk_empid"].alias("Source_EmployeeNo"),  
        df_employee["employeename"].alias("Source_EmployeeName"), 
        df_dimemployee["EmployeeNo"].alias("Target_EmployeeNo") ,
        df_dimemployee["EmployeeName"].alias("Target_EmployeeName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )

#joinDf.show()
filterDf = joinDf.filter(xxhash64(joinDf.Source_EmployeeNo, joinDf.Source_EmployeeName) != xxhash64(joinDf.Target_EmployeeNo, joinDf.Target_EmployeeName))

# Display filterDf
#filterDf.show()

mergeDf = filterDf.withColumn("MERGEKEY", concat(filterDf.Source_EmployeeNo, filterDf.Source_EmployeeName))

# Display mergeDf
mergeDf.show()
#   Only The updated Value will come
dummyDf = filterDf.filter("Target_EmployeeNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
dummyDf.show()

scdDf = mergeDf.union(dummyDf)

# Show scdDf
display(scdDf)


delta_table = DeltaTable.forPath(spark, "dbfs:/path/to/your/table")

# Define the merge condition
merge_condition = "scd.MERGEKEY = dim.EmployeeNo"

# Define the update condition
update_condition = "scd.Target_EmployeeNo is not null"

# Define the merge operation
delta_table.alias("dim").merge(
    scdDf.alias("scd"),
    merge_condition
).whenMatchedUpdate(
    condition=update_condition,
    set={
        "EmployeeName": F.col("scd.Source_EmployeeName"),
        "ActiveIndicator": F.col("scd.ActiveIndicator"),
        "startDate": F.col("scd.startDate"),
        "endDate": F.col("scd.endDate")
    }
).execute()

# Display the updated Delta table
delta_table.toDF().show()






# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dev.dimemployee

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dim

# COMMAND ----------

df_dimemployee = spark.read.format("delta").load("dbfs:/delta/dimemployee/part-00000-ebfbc5c2-a5d9-4dc3-9cfd-fefdce3a7de8-c000.snappy.parquet")
display(df_dimemployee)

# COMMAND ----------

