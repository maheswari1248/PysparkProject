# Databricks notebook source

#############################CSV FILE############################################################################################

# COMMAND ----------

from delta import * 
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from datetime import *

SourceDF=spark.read.csv("dbfs:/FileStore/EmployeeLoginDetails__1_.csv",header=True,inferSchema=True)
SourceDF=SourceDF.select("PK_EmpID","Employee Name").distinct()
display(SourceDF)

# COMMAND ----------

targetTable=DeltaTable.forPath(spark,"dbfs:/Project/Gold/dev.dimemployee/")
targetDF=targetTable.toDF()
#display(targetDF)

joinDf = SourceDF.join(targetDF, (targetDF["pk_empid"] == SourceDF["PK_EmpID"])& (targetDF["ActiveIndicator"] == lit('Y')), "left_outer") \
    .select(
        SourceDF["PK_EmpID"].alias("Source_EmployeeNo"),  
        SourceDF["Employee Name"].alias("Source_EmployeeName"), 
        targetDF["pk_empid"].alias("Target_EmployeeNo") ,
        targetDF["employeename"].alias("Target_EmployeeName") ,
        lit("Y").alias("ActiveIndicator"),  
        lit("2024-10-21").cast("timestamp").alias("startDate"),  
        lit(None).cast("timestamp").alias("endDate")
    )

display(joinDf)

display(targetTable)

# COMMAND ----------


#Filter
filterDf = joinDf.filter(xxhash64(joinDf.Source_EmployeeName) != xxhash64( joinDf.Target_EmployeeName))
filterDf.show()

# COMMAND ----------

#merge
mergeDf = filterDf.withColumn("MERGEKEY", filterDf.Source_EmployeeNo)

# Display mergeDf
mergeDf.show()

# COMMAND ----------

#Dummy
dummyDf = filterDf.filter("Target_EmployeeNo is not null").withColumn("MERGEKEY", lit(None))

# Show dummyDf
dummyDf.show()

# COMMAND ----------

scdDf = mergeDf.union(dummyDf)

# Show scdDf
scdDf.show()

# COMMAND ----------

final=targetTable.alias("target").merge(
    source=scdDf.alias("source"),
    condition="target.pk_empid == source.MERGEKEY and target.ActiveIndicator == 'Y'"
).whenMatchedUpdate(
    set={
        "ActiveIndicator": "'N'",
        "endDate": F.current_date()
    }
).whenNotMatchedInsert(
    values={
        "pk_empid": "source.Source_EmployeeNo",
        "employeename": "source.Source_EmployeeName",
        "ActiveIndicator": "'Y'",
        "startDate": F.current_date(),
        "endDate": F.lit(None)  # Using F.lit(None) to represent a null value
    }
).execute()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.dimemployee 

# COMMAND ----------

