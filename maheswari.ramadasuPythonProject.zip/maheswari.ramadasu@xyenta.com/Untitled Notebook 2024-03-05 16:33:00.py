# Databricks notebook source
data=[(1,"mahe"),(2,"Bhanu")]

df=spark.createDataFrame(data=data,schema=['id','name'])

# COMMAND ----------

from pyspark.sql.types import StructType
help(StructType)

# COMMAND ----------

data=[('mahi',{'hair':'black','eyes':'blue'}),('Ammu',{'hair':'Black','eyes':'black'})]
print(data)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType

schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("salary", FloatType(), True)
])

data = [(1, "Alice", 30, 50000.0), (2, "Bob", 35, 60000.0)]
df = spark.createDataFrame(data, schema)

# Save the DataFrame as a Delta table in the Bronze layer
bronze_table_path = "dbfs:/FileStore/shared_uploads/maheswari.ramadasu@xyenta.com"
df.write.format("delta").save(bronze_table_path)


# COMMAND ----------

spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")


# COMMAND ----------

